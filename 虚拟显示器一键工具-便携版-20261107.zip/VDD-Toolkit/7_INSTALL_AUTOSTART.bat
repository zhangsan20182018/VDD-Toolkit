@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PYEXE=%~dp0runtime\python.exe"
if exist "%PYEXE%" goto run
set "PYEXE=python"
:run
echo.
"%PYEXE%" "%~dp0core\setup_autostart.py" install
echo.
pause
