# -*- coding: utf-8 -*-
"""虚拟显示器 · 可视化控制面板（本地 Web UI）

双击 0_控制面板.bat 启动。本进程开一个只监听 127.0.0.1 的 HTTP 服务，
再用 Edge / Chrome 的 --app 模式打开独立窗口（看起来就是原生程序）。
所有操作都在页面上点按钮完成，不需要记命令、不需要懂配置文件。

设计要点：
  * 零外部依赖：只用便携 Python 标准库 + 现成的 vdd_lib / vdd_tool。
  * 不暴露外网：仅绑定 127.0.0.1，页面关掉 90 秒后服务自动退出。
  * 长时间操作（UAC 授权、切换分辨率、拾取窗口）走后台任务 + 前端轮询，
    不会卡住界面，每一步都有中文反馈。
  * 自动处理 UIPI：抖音直播伴侣以管理员运行时，点「一键开启」会自动
    弹一次 UAC 把保活宿主提升到管理员，无需用户理解权限概念。
"""
from __future__ import annotations

import ctypes
import json
import os
import re
import socket
import struct
import subprocess
import sys
import threading
import time
import zlib
from ctypes import wintypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import vdd_lib as L        # noqa: E402
import vdd_tool as T       # noqa: E402
import portrait_setup as P  # noqa: E402
import resolutions as R    # noqa: E402
import winreg              # noqa: E402

PORT = 17876
URL = "http://127.0.0.1:%d/" % PORT
HTML_PATH = os.path.join(HERE, "webui.html")
ASSET_DIR = os.path.join(HERE, "assets")
BRAND_LOGO = os.path.join(ASSET_DIR, "brand_logo.png")
APP_ICON_PNG = os.path.join(ASSET_DIR, "app_icon.png")
APP_ICON_ICO = os.path.join(ASSET_DIR, "app_icon.ico")
LOG_DIR = os.path.join(ROOT, "logs")
LOG_PATH = os.path.join(LOG_DIR, "webui.log")
CONFIG_PATH = os.path.join(ROOT, "config.ini")
ADMIN_RESULT = os.path.join(LOG_DIR, "admin_host_result.json")
PYW = os.path.join(ROOT, "runtime", "pythonw.exe")

IS_ADMIN = False
try:
    IS_ADMIN = bool(ctypes.windll.shell32.IsUserAnAdmin())
except Exception:
    pass

LAST_POLL = time.time()
TASKS = {}
TASK_LOCK = threading.Lock()


def log_line(msg):
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write("%s  %s\n" % (time.strftime("%H:%M:%S"), msg))
    except Exception:
        pass


# ------------------------------------------------------------------ 配置改写
def write_config_value(key, value):
    """就地改 config.ini 的某个键，保留全部中文注释。"""
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        text = f.read()
    pattern = r"(?m)^([ \t]*%s[ \t]*=[ \t]*)[^\r\n;]+" % re.escape(key)
    new, n = re.subn(pattern, lambda m: m.group(1) + str(value), text, count=1)
    if n == 0:
        raise RuntimeError("config.ini 里找不到 %s" % key)
    with open(CONFIG_PATH, "w", encoding="utf-8", newline="") as f:
        f.write(new)


def autostart_state():
    try:
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                           r"Software\Microsoft\Windows\CurrentVersion\Run")
        winreg.QueryValueEx(k, "VDD-Host")
        return True
    except OSError:
        return False


def host_privilege():
    """读宿主自己上报的权限级别。面板是普通权限时，用 window_is_protected
    判断会一直显示「需授权」，即使管理员宿主已经在跑 —— 必须看宿主的。"""
    try:
        with open(T.HOST_INFO, "r", encoding="utf-8") as f:
            info = json.load(f)
        if L.singleton_exists():
            return info
    except Exception:
        pass
    return {"admin": False}


# ------------------------------------------------------------------ 状态
def build_status():
    cfg = T.load_config()
    name = L.find_vdd_display_name()
    dm = L.current_mode(name) if name else None
    rect = L.vdd_screen_rect()
    vdd = None
    scale = 1.0
    if name:
        vdd = {
            "name": name,
            "x": rect[0] if rect else 0, "y": rect[1] if rect else 0,
            "w": dm.dmPelsWidth if dm else (rect[2] if rect else 0),
            "h": dm.dmPelsHeight if dm else (rect[3] if rect else 0),
            "hz": dm.dmDisplayFrequency if dm else 60,
            "logical_w": rect[2] if rect else 0,
            "logical_h": rect[3] if rect else 0,
        }
        if rect and rect[2] and dm and dm.dmPelsWidth:
            scale = round(dm.dmPelsWidth / float(rect[2]), 2)

    wins = T.candidate_windows(cfg)
    target = None
    if wins:
        h, title, pid, pname = wins[0]
        target = {
            "hwnd": int(h), "title": title, "pname": pname,
            "rect": L.window_rect(h),
            "protected": L.window_is_protected(h),
            "on_vdd": False,
        }
        if target["rect"] and rect:
            r = target["rect"]
            target["on_vdd"] = (abs(r[0] - rect[0]) < 40
                                and abs(r[1] - rect[1]) < 40)

    windows = []
    for h, title, pid, pname in L.enum_windows():
        r = L.window_rect(h)
        if not title or not r or r[2] < 160 or r[3] < 120:
            continue
        windows.append({
            "hwnd": int(h), "title": title[:60], "pname": pname,
            "rect": list(r),
        })

    presets = R.presets_status()
    cur_key = None
    if dm:
        for p in presets:
            if p["w"] == dm.dmPelsWidth and p["h"] == dm.dmPelsHeight:
                cur_key = p["key"]
                break

    try:
        driver = bool(L.list_device_interfaces(L.VDD_ADAPTER_GUID))
    except Exception:
        driver = False

    return {
        "ok": True,
        "admin": IS_ADMIN,
        "host_admin": bool(host_privilege().get("admin")),
        "driver": driver,
        "host": L.singleton_exists(),
        "vdd": vdd,
        "dpi_scale": scale,
        "target": target,
        "windows": windows[:40],
        "presets": presets,
        "current_preset": cur_key,
        "config": {
            "width": cfg["width"], "height": cfg["height"], "hz": cfg["hz"],
            "title_keywords": cfg["title_keywords"],
            "borderless": cfg["borderless"],
            "portrait_box": cfg["portrait_box"],
            "hotkey": cfg["hotkey"],
        },
        "saved_target": T.load_target(),
        "autostart": autostart_state(),
        "preview": bool(name),
    }


# ------------------------------------------------------------------ 虚拟屏预览图
class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD), ("biWidth", ctypes.c_long),
        ("biHeight", ctypes.c_long), ("biPlanes", wintypes.WORD),
        ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", ctypes.c_long),
        ("biYPelsPerMeter", ctypes.c_long), ("biClrUsed", wintypes.DWORD),
        ("biClrImportant", wintypes.DWORD),
    ]


_GDI_READY = False


def _setup_gdi():
    global _GDI_READY
    if _GDI_READY:
        return
    u = ctypes.windll.user32
    g = ctypes.windll.gdi32
    u.GetDC.argtypes = [wintypes.HWND]
    u.GetDC.restype = wintypes.HDC
    u.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
    g.CreateCompatibleDC.argtypes = [wintypes.HDC]
    g.CreateCompatibleDC.restype = wintypes.HDC
    g.CreateCompatibleBitmap.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int]
    g.CreateCompatibleBitmap.restype = wintypes.HBITMAP
    g.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
    g.SelectObject.restype = wintypes.HGDIOBJ
    g.StretchBlt.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int,
                             ctypes.c_int, ctypes.c_int, wintypes.HDC,
                             ctypes.c_int, ctypes.c_int, ctypes.c_int,
                             ctypes.c_int, wintypes.DWORD]
    g.StretchBlt.restype = wintypes.BOOL
    g.SetStretchBltMode.argtypes = [wintypes.HDC, ctypes.c_int]
    g.SetStretchBltMode.restype = ctypes.c_int
    g.GetDIBits.argtypes = [wintypes.HDC, wintypes.HBITMAP, wintypes.UINT,
                            wintypes.UINT, ctypes.c_void_p, ctypes.c_void_p,
                            wintypes.UINT]
    g.GetDIBits.restype = ctypes.c_int
    g.DeleteObject.argtypes = [wintypes.HGDIOBJ]
    g.DeleteDC.argtypes = [wintypes.HDC]
    _GDI_READY = True


def _png_chunk(tag, data):
    return (struct.pack(">I", len(data)) + tag + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))


def capture_vdd_png(max_w=330, max_h=600):
    """把虚拟屏整屏缩略成 PNG（纯标准库实现，无需 Pillow）。"""
    rect = L.vdd_screen_rect()
    if not rect:
        return None
    _setup_gdi()
    x, y, w, h = rect
    ratio = min(max_w / float(w), max_h / float(h), 1.0)
    tw, th = max(1, int(w * ratio)), max(1, int(h * ratio))
    u = ctypes.windll.user32
    g = ctypes.windll.gdi32
    screen = u.GetDC(0)
    if not screen:
        return None
    mem = g.CreateCompatibleDC(screen)
    bmp = g.CreateCompatibleBitmap(screen, tw, th)
    old = g.SelectObject(mem, bmp)
    try:
        SRCCOPY = 0x00CC0020
        g.SetStretchBltMode(mem, 4)          # HALFTONE：缩小画面时少一些彩色噪点
        g.StretchBlt(mem, 0, 0, tw, th, screen, x, y, w, h, SRCCOPY)
        bi = BITMAPINFOHEADER()
        bi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        bi.biWidth, bi.biHeight = tw, th
        bi.biPlanes, bi.biBitCount, bi.biCompression = 1, 32, 0
        buf = ctypes.create_string_buffer(tw * th * 4)
        if not g.GetDIBits(mem, bmp, 0, th, buf, ctypes.byref(bi), 0):
            return None
        raw = buf.raw
        rows = []
        for row in range(th - 1, -1, -1):       # DIB 是自下而上
            line = raw[row * tw * 4:(row + 1) * tw * 4]
            rgb = bytearray(tw * 3)
            rgb[0::3] = line[2::4]              # BGRA -> RGB
            rgb[1::3] = line[1::4]
            rgb[2::3] = line[0::4]
            rows.append(b"\x00" + bytes(rgb))
        body = b"".join(rows)
        return (b"\x89PNG\r\n\x1a\n"
                + _png_chunk(b"IHDR", struct.pack(">IIBBBBB", tw, th, 8, 2, 0, 0, 0))
                + _png_chunk(b"IDAT", zlib.compress(body, 6))
                + _png_chunk(b"IEND", b""))
    finally:
        g.SelectObject(mem, old)
        g.DeleteObject(bmp)
        g.DeleteDC(mem)
        u.ReleaseDC(0, screen)


_preview_cache = {"png": None, "at": 0.0}


def preview_png():
    now = time.time()
    if _preview_cache["png"] and now - _preview_cache["at"] < 1.0:
        return _preview_cache["png"]
    png = capture_vdd_png()
    if png:
        # 切换分辨率 / 驱动刷新那一两秒会抓到全黑帧（纯色 PNG 只有几百字节）。
        # 短时间保留上一帧，避免面板闪一下「黑屏」让新手以为坏了。
        if (len(png) < 3000 and _preview_cache["png"]
                and now - _preview_cache["at"] < 8.0):
            return _preview_cache["png"]
        _preview_cache["png"] = png
        _preview_cache["at"] = now
    return png


# ------------------------------------------------------------------ 后台任务
def new_task(fn, params):
    tid = str(time.time_ns())
    with TASK_LOCK:
        TASKS[tid] = {"logs": [], "done": False, "ok": None, "msg": ""}
        if len(TASKS) > 12:
            for k in sorted(TASKS)[:len(TASKS) - 12]:
                TASKS.pop(k, None)

    def emit(s):
        s = str(s)
        with TASK_LOCK:
            TASKS[tid]["logs"].append(s)
        log_line(s)

    def worker():
        try:
            ok, msg = fn(emit, params or {})
        except Exception as e:
            ok, msg = False, "%s: %s" % (type(e).__name__, e)
            emit("[异常] " + msg)
        with TASK_LOCK:
            TASKS[tid]["done"] = True
            TASKS[tid]["ok"] = bool(ok)
            TASKS[tid]["msg"] = msg or ("完成" if ok else "未完成")

    threading.Thread(target=worker, daemon=True).start()
    return tid


# ------------------------------------------------------------------ 具体动作
def request_move(emit):
    """让「有权限的那一方」去投送。

    面板通常是普通权限，直接 do_move 会被 UIPI 拒绝；管理员宿主在跑时，
    写一张 MOVE_NOW 便条请它立刻投一次即可，不必再弹 UAC。
    """
    if host_privilege().get("admin") and L.singleton_exists():
        try:
            with open(T.MOVE_NOW, "w", encoding="utf-8") as f:
                f.write("move\n")
            emit(" 已通知管理员宿主立即投送……")
            time.sleep(1.3)
            return True
        except Exception as e:
            emit(" 通知宿主失败，改由面板直接试：%s" % e)
    cfg = T.load_config()
    n = T.do_move(cfg, verbose=False)
    emit(" 本次移动 %d 个窗口（已在位的会跳过）" % n)
    return True


def elevate_admin_host(emit):
    """弹一次 UAC，让 admin_host.py 的提权进程自己常驻为管理员宿主。"""
    emit(" 正在停止普通权限宿主，准备切换到管理员宿主……")
    try:
        P.stop_host()
    except Exception:
        pass
    time.sleep(0.8)
    try:
        if os.path.isfile(ADMIN_RESULT):
            os.remove(ADMIN_RESULT)
    except Exception:
        pass
    script = os.path.join(HERE, "admin_host.py")
    target = PYW if os.path.isfile(PYW) else sys.executable
    params = '"%s" --elevated' % script
    rc = ctypes.windll.shell32.ShellExecuteW(
        None, "runas", target, params, ROOT, 0,
    )
    if rc <= 32:
        emit(" [失败] 无法请求管理员权限（UAC 可能被取消，rc=%s）" % rc)
        return False
    emit(" Windows 授权弹窗已出现，请在弹窗里点「是」……")
    deadline = time.time() + 90
    while time.time() < deadline:
        if os.path.isfile(ADMIN_RESULT):
            time.sleep(0.5)
            try:
                with open(ADMIN_RESULT, "r", encoding="utf-8") as f:
                    res = json.load(f)
                for s in res.get("steps", []):
                    emit("   - " + s)
            except Exception:
                pass
            emit(" 管理员宿主已就绪")
            return True
        time.sleep(0.5)
    emit(" [失败] 等待授权超时")
    return False


def act_start(emit, p):
    emit("=== 一键开启直播投屏 ===")
    cfg = T.load_config()
    wins = T.candidate_windows(cfg)
    admin_host = bool(host_privilege().get("admin") and L.singleton_exists())
    if admin_host:
        emit(" 管理员宿主已在运行，无需再次授权。")
    if wins:
        emit(" 目标画面窗口：%s（%s）" % (wins[0][1], wins[0][3]))
        # 注意：window_is_protected 是「相对本面板进程」的，管理员宿主已就位时
        # 即使它仍返回 True，也不该再弹 UAC。
        if L.window_is_protected(wins[0][0]) and not admin_host:
            emit(" 这个窗口以管理员权限运行，普通权限搬不动它。")
            if not elevate_admin_host(emit):
                return False, "管理员授权未完成"
        elif not L.singleton_exists():
            emit(" 正在启动保活宿主……")
            P.start_host()
    else:
        emit(" 暂时没找到画面窗口，仍会先把虚拟屏点亮。")
        if not L.singleton_exists():
            P.start_host()

    if not T.wait_for_vdd(timeout=25.0):
        return False, "虚拟屏未能点亮，请检查驱动"
    name = L.find_vdd_display_name()
    dm = L.current_mode(name)
    if dm:
        emit(" 虚拟屏已点亮：%s  %dx%d@%dHz" % (
            name, dm.dmPelsWidth, dm.dmPelsHeight, dm.dmDisplayFrequency))
    if dm and (dm.dmPelsWidth, dm.dmPelsHeight) != (cfg["width"], cfg["height"]):
        emit(" 正在应用设定的分辨率 %dx%d……" % (cfg["width"], cfg["height"]))
        code, msg = L.set_display_mode(cfg["width"], cfg["height"], cfg["hz"])
        emit("   %s (code=%d)" % (msg, code))
        time.sleep(0.8)

    time.sleep(0.6)
    request_move(emit)
    cur = T.candidate_windows(T.load_config())
    vr = L.vdd_screen_rect()
    if cur and vr:
        r = L.window_rect(cur[0][0])
        on = bool(r and abs(r[0] - vr[0]) < 40 and abs(r[1] - vr[1]) < 40)
        emit(" 画面窗口位置：%s -> %s" % (r, "已铺在虚拟屏 ✓" if on else "还没到虚拟屏 ✗"))
        if not on and L.window_is_protected(cur[0][0]):
            emit(" 仍被系统权限拦截，请再点一次「一键开启」并完成授权。")
    emit("=== 完成：保持本面板开启，虚拟屏会一直亮着 ===")
    return True, "一键开启完成"


def act_stop(emit, p):
    emit("=== 关闭虚拟屏 ===")
    try:
        P.stop_host()
    except Exception as e:
        emit(" 停止宿主时出错：%s" % e)
    time.sleep(1.0)
    emit(" 虚拟屏已关闭" if not L.find_vdd_display_name()
         else " 系统里仍有残留，已再次尝试拔出")
    return True, "已关闭"


def act_mode(emit, p):
    w, h, hz = int(p.get("w")), int(p.get("h")), int(p.get("hz", 60))
    emit("=== 切换分辨率 %dx%d@%dHz ===" % (w, h, hz))
    ok, _ = R.switch(w, h, hz, emit=emit)
    if ok:
        time.sleep(0.5)
        request_move(emit)
        emit(" 已按新分辨率重新投送画面窗口")
    return ok, "切换成功" if ok else "切换未完成"


def act_move(emit, p):
    cfg = T.load_config()
    if not L.vdd_screen_rect():
        return False, "虚拟屏还没点亮，请先点「一键开启」"
    wins = T.candidate_windows(cfg)
    if not wins:
        return False, "没找到画面窗口，请用「拾取窗口」或下方下拉框选择"
    h = wins[0][0]
    if L.window_is_protected(h) and not host_privilege().get("admin"):
        emit(" 该窗口受管理员权限保护，正在请求授权……")
        if not elevate_admin_host(emit):
            return False, "授权未完成"
        T.wait_for_vdd(timeout=20.0)
    request_move(emit)
    return True, "投送完成"


def act_pick(emit, p):
    """8 秒内点一下目标窗口；统计前台窗口出现次数，避免用户切回面板选错。"""
    emit("=== 拾取画面窗口 ===")
    emit(" 请在 8 秒内，用鼠标点一下要投送的直播画面窗口……")
    ignore = {"msedge.exe", "chrome.exe", "python.exe", "pythonw.exe",
              "workbuddy.exe", "explorer.exe", "textinputhost.exe"}
    counts = {}
    deadline = time.time() + 8
    while time.time() < deadline:
        h = L.foreground_window()
        if h:
            title, pid, pname = T.window_info(h)
            if title and pname.lower() not in ignore:
                key = (int(h), title, pname)
                counts[key] = counts.get(key, 0) + 1
        time.sleep(0.2)
    if not counts:
        return False, "没有捕获到窗口，请再试一次（点完可以切回本面板）"
    (hwnd, title, pname), _ = max(counts.items(), key=lambda kv: kv[1])
    emit(" 已选中：%s（%s）" % (title, pname))
    T.save_target(hwnd, title, pname)
    # 同步写进关键词：窗口重启后 hwnd 变了也能按标题找回来。
    kw = re.sub(r"[,;#\r\n]", " ", title).strip()[:40] or "预览画面"
    try:
        write_config_value("title_keywords", kw)
        emit(" 已记住窗口标题关键词：%s" % kw)
    except Exception as e:
        emit(" 关键词写入失败（不影响按句柄跟踪）：%s" % e)
    if L.vdd_screen_rect():
        request_move(emit)
        emit(" 已立即投送到虚拟屏")
    if L.window_is_protected(hwnd) and not host_privilege().get("admin"):
        emit(" 该窗口需要管理员权限，点「一键开启」完成授权即可自动投送")
    return True, "已记住：" + title


def act_target(emit, p):
    hwnd = int(p.get("hwnd"))
    title, pid, pname = T.window_info(hwnd)
    if not title:
        return False, "窗口已不存在，请刷新列表"
    T.save_target(hwnd, title, pname)
    kw = re.sub(r"[,;#\r\n]", " ", title).strip()[:40] or "预览画面"
    try:
        write_config_value("title_keywords", kw)
    except Exception:
        pass
    emit(" 已设为目标：%s（%s）" % (title, pname))
    if L.vdd_screen_rect():
        request_move(emit)
        emit(" 已投送到虚拟屏")
    return True, "已选择 " + title


def act_clear_target(emit, p):
    T.clear_target()
    try:
        write_config_value("title_keywords", "预览画面")
    except Exception:
        pass
    emit(" 已清除记住的窗口，恢复为按标题「预览画面」自动查找")
    return True, "已清除"


def act_borderless(emit, p):
    val = 1 if int(p.get("value", 0)) else 0
    write_config_value("borderless", val)
    emit(" 无边框模式：%s（下一次投送生效）" % ("开" if val else "关"))
    if L.vdd_screen_rect():
        request_move(emit)
    return True, "已更新"


def act_autostart(emit, p):
    action = "install" if int(p.get("value", 0)) else "remove"
    py = sys.executable
    r = subprocess.run(
        [py, os.path.join(HERE, "setup_autostart.py"), action],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30,
    )
    out = r.stdout.decode("utf-8", errors="replace").strip()
    emit(" " + out.replace("\n", " / "))
    return r.returncode == 0, "开机自启已" + ("开启" if action == "install" else "关闭")


def act_restart(emit, p):
    emit("=== 重启保活宿主 ===")
    P.stop_host()
    time.sleep(1.0)
    P.start_host()
    emit(" 等待虚拟屏重新点亮……")
    ok = bool(T.wait_for_vdd(timeout=25.0))
    if ok:
        time.sleep(0.8)
        request_move(emit)
    emit(" 重启完成" if ok else " 重启后未检测到虚拟屏")
    if ok and not host_privilege().get("admin"):
        emit(" 提示：重启后的宿主是普通权限，投管理员窗口请点「一键开启」完成授权")
    return ok, "重启完成" if ok else "重启未完成"


ACTIONS = {
    "start": act_start,
    "stop": act_stop,
    "mode": act_mode,
    "move": act_move,
    "pick": act_pick,
    "target": act_target,
    "clear_target": act_clear_target,
    "borderless": act_borderless,
    "autostart": act_autostart,
    "restart": act_restart,
}


# ------------------------------------------------------------------ HTTP
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, code, body, ctype, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8")

    def do_GET(self):
        global LAST_POLL
        path = self.path.split("?")[0]
        if path in ("/", "/index.html"):
            LAST_POLL = time.time()
            try:
                with open(HTML_PATH, "rb") as f:
                    self._send(200, f.read(), "text/html; charset=utf-8")
            except OSError as e:
                self._send(500, str(e).encode("utf-8"), "text/plain; charset=utf-8")
            return
        # 品牌 logo 与窗口图标（随工具包一起复制；文件缺失时不影响主界面）
        if path in ("/logo.png", "/favicon.png", "/favicon.ico"):
            fpath = (BRAND_LOGO if path == "/logo.png"
                     else APP_ICON_ICO if path.endswith(".ico") else APP_ICON_PNG)
            ctype = "image/x-icon" if path.endswith(".ico") else "image/png"
            try:
                with open(fpath, "rb") as f:
                    self._send(200, f.read(), ctype)
            except OSError:
                self._send(404, b"not found", "text/plain; charset=utf-8")
            return
        if path == "/api/ping":
            self._json({"ok": True, "service": "vdd-panel"})
            return
        if path == "/api/status":
            LAST_POLL = time.time()
            try:
                self._json(build_status())
            except Exception as e:
                self._json({"ok": False, "error": "%s: %s" % (type(e).__name__, e)}, 500)
            return
        if path == "/api/windows":
            LAST_POLL = time.time()
            try:
                self._json({"ok": True, "windows": build_status()["windows"]})
            except Exception as e:
                self._json({"ok": False, "error": str(e)}, 500)
            return
        if path == "/api/preview.png":
            LAST_POLL = time.time()
            png = preview_png()
            if png:
                self._send(200, png, "image/png")
            else:
                self._send(204, b"", "image/png")
            return
        if path == "/api/task":
            LAST_POLL = time.time()
            from urllib.parse import parse_qs, urlparse
            tid = parse_qs(urlparse(self.path).query).get("id", [""])[0]
            with TASK_LOCK:
                t = dict(TASKS.get(tid, {}))
                if t:
                    t["logs"] = list(t["logs"])
            self._json(t or {"done": True, "ok": False,
                             "msg": "任务不存在", "logs": []})
            return
        self._send(404, b"not found", "text/plain; charset=utf-8")

    def do_POST(self):
        global LAST_POLL
        LAST_POLL = time.time()
        if self.path.split("?")[0] != "/api/action":
            self._json({"ok": False, "error": "unknown endpoint"}, 404)
            return
        try:
            n = int(self.headers.get("Content-Length", "0"))
            data = json.loads(self.rfile.read(n) or b"{}")
            name = data.get("name", "")
            params = data.get("params", {}) or {}
        except Exception as e:
            self._json({"ok": False, "error": "bad request: %s" % e}, 400)
            return
        if name not in ACTIONS:
            self._json({"ok": False, "error": "unknown action: %s" % name}, 400)
            return
        tid = new_task(ACTIONS[name], params)
        self._json({"ok": True, "id": tid})


# ------------------------------------------------------------------ 启动
def find_browser():
    roots = [os.environ.get("ProgramFiles(x86)", ""),
             os.environ.get("ProgramFiles", ""),
             os.environ.get("LOCALAPPDATA", "")]
    rels = [
        r"Microsoft\Edge\Application\msedge.exe",
        r"Google\Chrome\Application\chrome.exe",
    ]
    for root in roots:
        for rel in rels:
            p = os.path.join(root, rel)
            if os.path.isfile(p):
                return p
    return None


def open_panel():
    # VDD_NO_BROWSER=1 只起服务、不自动弹浏览器（自动化验收 / 高级用法）
    if os.environ.get("VDD_NO_BROWSER") == "1":
        return
    exe = find_browser()
    if exe:
        profile = os.path.join(os.environ.get("TEMP", ROOT), "VDD-ControlPanel")
        args = [exe, "--app=" + URL, "--window-size=1200,940",
                "--window-position=120,60",
                "--no-first-run", "--no-default-browser-check",
                "--disable-features=msEdgeSidebarV2",
                "--user-data-dir=" + profile]
        try:
            subprocess.Popen(args, stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             close_fds=True)
            return
        except Exception:
            pass
    import webbrowser
    webbrowser.open(URL)


def service_alive():
    """用 HTTP 心跳判断，而不是裸 TCP 连接。

    旧服务刚被结束、端口还残留 TIME_WAIT / 半关闭连接时，connect_ex 可能
    短暂成功，会让新进程误以为「已有面板在跑」而直接退出（实测踩过）。
    """
    try:
        import urllib.request
        op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with op.open(URL + "api/ping", timeout=0.8) as r:
            return r.status == 200
    except Exception:
        return False


def idle_watch(server):
    """页面关掉一段时间后自动退出，避免留下后台进程。宿主是独立进程，不受影响。"""
    while True:
        time.sleep(5)
        if time.time() - LAST_POLL > 120:
            log_line("页面已关闭，控制面板服务退出（保活宿主不受影响）")
            try:
                server.shutdown()
            except Exception:
                pass
            return


def main():
    os.makedirs(LOG_DIR, exist_ok=True)
    if service_alive():
        # 已经有面板在跑：只再打开一个窗口，不重复起服务。
        log_line("已有控制面板服务在运行，只打开窗口")
        open_panel()
        return 0
    log_line("控制面板启动（管理员=%s）" % IS_ADMIN)
    try:
        server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError as e:
        log_line("端口绑定失败: %s" % e)
        if service_alive():
            open_panel()
            return 0
        return 1
    server.daemon_threads = True
    threading.Thread(target=idle_watch, args=(server,), daemon=True).start()
    open_panel()
    if "--auto" in sys.argv:
        # 双击入口 = 全自动：页面打开后自己跑一遍「一键开启」，
        # 新手连按钮都不用点；已开启时它是幂等的，只会重新投送一次。
        def auto():
            time.sleep(1.5)
            log_line("自动执行一键开启")
            new_task(act_start, {})
        threading.Thread(target=auto, daemon=True).start()
    try:
        server.serve_forever(poll_interval=0.4)
    except KeyboardInterrupt:
        pass
    log_line("控制面板服务结束")
    return 0


if __name__ == "__main__":
    sys.exit(main())
