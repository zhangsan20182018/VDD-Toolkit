@echo off
cd /d "%~dp0.."
start "" "runtime\pythonw.exe" "core\vdd_tool.py" host
exit /b 0
