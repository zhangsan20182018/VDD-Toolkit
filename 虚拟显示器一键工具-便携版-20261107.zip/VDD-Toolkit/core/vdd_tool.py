# -*- coding: utf-8 -*-
"""
vdd_tool.py -- 虚拟显示器一键工具（命令行入口）

用法见 README.md。核心命令：
  host      常驻：点亮虚拟屏 + 设置分辨率 + 持续保活 + 自动投送 + 全局热键
  status    查看驱动 / 虚拟屏 / 显示器状态
  screens   列出所有显示器及其坐标
  windows   列出所有可见窗口（用于填写 config.ini 的窗口标题关键词）
  pick      交互式「拾取窗口」：倒计时内激活目标窗口，自动记住并投送
  move      手动把预览窗口移到虚拟屏一次
  modes     列出驱动支持的分辨率（检查竖屏模式是否可用）
  setmode   单独重设虚拟屏分辨率 / 刷新率
  remove    移除全部虚拟屏
  check     仅检测驱动是否可用（供 bat 判断是否需要安装驱动，用退出码）

热键（需 host 在运行）：
  Ctrl+Alt+V  把当前活动窗口投到虚拟屏
  Ctrl+Alt+B  把当前活动窗口送回主屏
"""
from __future__ import annotations

import argparse
import configparser
import json
import os
import re
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vdd_lib as L

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(ROOT, "config.ini")
LOG_DIR = os.path.join(ROOT, "logs")
LOG_PATH = os.path.join(LOG_DIR, "host.log")
STOP_FLAG = os.path.join(LOG_DIR, "STOP.flag")
TARGET_PATH = os.path.join(LOG_DIR, "target.json")
# 宿主上报自己的完整性级别；控制面板据此判断是否需要再弹 UAC。
HOST_INFO = os.path.join(LOG_DIR, "host_privilege.json")
# 控制面板写这个标记，请宿主立刻投送一次（面板自己可能没权限搬窗口）。
MOVE_NOW = os.path.join(LOG_DIR, "MOVE_NOW.flag")

DEFAULTS = {
    "width": 1920,
    "height": 1080,
    "hz": 60,
    "title_keywords": "抖音直播伴侣,画面预览",
    "process_keywords": "",
    "borderless": 0,
    "auto_move": 1,
    "mode": "maximize",
    "max_windows": 1,
    "poll_seconds": 2.0,
    "hotkey": 1,
    "portrait_box": 0,
}

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def log(msg):
    line = "%s  %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    try:
        print(line, flush=True)
    except Exception:
        pass
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def load_config():
    c = dict(DEFAULTS)
    if not os.path.isfile(CONFIG_PATH):
        return c
    cp = configparser.ConfigParser()
    try:
        cp.read(CONFIG_PATH, encoding="utf-8")
    except Exception as e:
        log("config.ini 读取失败，使用默认值: %s" % e)
        return c
    if cp.has_section("display"):
        for k in ("width", "height", "hz"):
            if cp.has_option("display", k):
                try:
                    c[k] = int(cp.get("display", k).strip())
                except ValueError:
                    pass
    if cp.has_section("window"):
        for k in ("title_keywords", "process_keywords", "mode"):
            if cp.has_option("window", k):
                c[k] = cp.get("window", k).strip()
        for k in ("borderless", "auto_move", "max_windows", "portrait_box"):
            if cp.has_option("window", k):
                try:
                    c[k] = int(cp.get("window", k).strip())
                except ValueError:
                    pass
    if cp.has_section("host"):
        if cp.has_option("host", "poll_seconds"):
            try:
                c["poll_seconds"] = float(cp.get("host", "poll_seconds").strip())
            except ValueError:
                pass
        if cp.has_option("host", "hotkey"):
            try:
                c["hotkey"] = int(cp.get("host", "hotkey").strip())
            except ValueError:
                pass
    return c


def split_keywords(text):
    return [k.strip() for k in str(text).replace("，", ",").split(",") if k.strip()]


# ------------------------------------------------------- 记住「拾取」过的窗口
def load_target():
    try:
        with open(TARGET_PATH, "r", encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict) and d.get("hwnd"):
            return d
    except Exception:
        pass
    return None


def save_target(hwnd, title, pname):
    os.makedirs(LOG_DIR, exist_ok=True)
    data = {
        "hwnd": int(hwnd),
        "title": title,
        "process": pname,
        "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    with open(TARGET_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return data


def clear_target():
    try:
        if os.path.isfile(TARGET_PATH):
            os.remove(TARGET_PATH)
    except Exception:
        pass


def window_info(hwnd):
    """由 hwnd 取回 (标题, pid, 进程名)。"""
    for h, title, pid, pname in L.enum_windows():
        if h == hwnd:
            return title, pid, pname
    return "", 0, ""


def describe_monitor(m):
    dev, l, t, r, b, primary = m
    return "%s  (%d,%d) %dx%d  %s" % (dev, l, t, r - l, b - t, "主屏" if primary else "扩展屏")


# ------------------------------------------------------------------ 命令
def start_hotkey_listener():
    """在独立线程里注册并监听全局热键（需要该线程自己的消息循环）。"""
    HOTKEY_VDDR, HOTKEY_MAIN = 1, 2

    def worker():
        ok_v = L.register_hotkey(HOTKEY_VDDR, L.VK_V)
        ok_b = L.register_hotkey(HOTKEY_MAIN, L.VK_B)
        if not (ok_v or ok_b):
            log("全局热键注册失败，可能被其它软件占用；仍可用 11_PICK_WINDOW.bat 拾取窗口")
            return
        log("全局热键已注册: %s%s" % (
            "Ctrl+Alt+V 投到虚拟屏 " if ok_v else "",
            "Ctrl+Alt+B 送回主屏" if ok_b else "",
        ))
        msg = L.MSG()
        while True:
            r = L.get_message(msg)
            if r <= 0:
                return
            if msg.message != L.WM_HOTKEY:
                continue
            hwnd = L.foreground_window()
            if not (hwnd and L.is_window_visible(hwnd)):
                log("热键忽略：当前没有可见的前台窗口")
                continue
            try:
                move_hotkey_window(hwnd, back=(msg.wParam == HOTKEY_MAIN))
            except Exception as e:
                log("热键处理异常: %s" % e)

    th = threading.Thread(target=worker, daemon=True, name="vdd-hotkey")
    th.start()
    return th


def cmd_check(args):
    """退出码 0=驱动可用且能打开；1=驱动缺失/不可用。"""
    try:
        v = L.VDD()
        v.open()
        v.close()
        print("DRIVER_OK")
        return 0
    except Exception as e:
        print("DRIVER_MISSING: %s" % e)
        return 1


def cmd_status(args):
    print("=" * 62)
    print(" 虚拟显示器状态检查")
    print("=" * 62)
    try:
        v = L.VDD()
        path = v.open()
        print(" [驱动] 已安装 / 可访问")
        print("        设备路径: %s" % path)
        try:
            print("        驱动版本(minor): %s" % v.version())
        except Exception:
            pass
        v.close()
    except Exception as e:
        print(" [驱动] 不可用 -> %s" % e)
        print("        请以管理员身份运行 5_INSTALL_DRIVER.bat，然后重启电脑。")
    name = L.find_vdd_display_name()
    print(" [虚拟屏] %s" % (name if name else "未点亮（需要运行 1_START.bat 启动保活宿主）"))
    if name:
        dm = L.current_mode(name)
        if dm:
            print("        当前模式: %dx%d @ %dHz %dbpp" % (
                dm.dmPelsWidth, dm.dmPelsHeight, dm.dmDisplayFrequency, dm.dmBitsPerPel,
            ))
        rect = L.vdd_screen_rect()
        if rect:
            print("        桌面坐标: (%d,%d) %dx%d" % rect)
    print(" [显示器列表]")
    for m in L.monitors():
        print("        " + describe_monitor(m))
    print("=" * 62)
    return 0


def cmd_screens(args):
    rows = L.monitors()
    if not rows:
        print("没有检测到显示器")
        return 1
    for i, m in enumerate(rows):
        print("[%d] %s" % (i, describe_monitor(m)))
    name = L.find_vdd_display_name()
    print("\n虚拟显示器设备名: %s" % (name or "（未点亮）"))
    return 0


def cmd_windows(args):
    wins = L.enum_windows()
    print("可见顶层窗口共 %d 个：\n" % len(wins))
    print("  %-10s %-28s %-42s %s" % ("HWND", "进程", "位置/尺寸", "标题"))
    print("  " + "-" * 110)
    for hwnd, title, pid, pname in wins:
        r = L.window_rect(hwnd)
        pos = "%d,%d %dx%d" % r if r else "?"
        print("  0x%-8X %-28s %-42s %s" % (
            hwnd & 0xFFFFFFFF, (pname or "?")[:28], pos, title[:60],
        ))
    print("\n把要投送的窗口标题里的独特关键词填进 config.ini 的 title_keywords。")
    return 0


def target_rect(cfg):
    """虚拟屏上实际要放置窗口的矩形。

    portrait_box=1 时按 9:16 在横屏虚拟屏里居中留黑边，采集端裁中间即可，
    不需要管理员权限，也不需要驱动支持竖屏模式。
    """
    rect = L.vdd_screen_rect()
    if not rect:
        return None
    if not cfg.get("portrait_box"):
        return rect
    x, y, w, h = rect
    pw = min(w, int(round(h * 9.0 / 16.0)))
    return (x + (w - pw) // 2, y, pw, h)


def primary_rect():
    for dev, l, t, r, b, primary in L.monitors():
        if primary:
            return (l, t, r - l, b - t)
    return (0, 0, 1920, 1080)


def place_window(hwnd, rect, cfg):
    x, y, w, h = rect
    mode = "fill" if cfg.get("portrait_box") else cfg["mode"]
    return L.move_window_to(
        hwnd, x, y, w, h,
        borderless=bool(cfg["borderless"]),
        maximize=(mode == "maximize"),
    )


def candidate_windows(cfg):
    """关键词优先，拾取记住的窗口句柄兜底。

    早期版本把记住的 hwnd 放在最前面，实测出现过「记住了 WorkBuddy 窗口后，
    抖音预览画面再也投不过去」的问题：只要那个 hwnd 还在，关键词就永远不生效。
    现在改为先按标题关键词找；只有当关键词一个都匹配不到（例如直播伴侣把
    标题改了）时，才回退到记住的 hwnd，兼顾稳定与准确。
    """
    hits = L.match_windows(
        split_keywords(cfg["title_keywords"]),
        split_keywords(cfg["process_keywords"]),
    )
    if hits:
        return hits
    tgt = load_target()
    if tgt:
        hwnd = int(tgt["hwnd"])
        if L.is_window(hwnd) and L.is_window_visible(hwnd):
            title, pid, pname = window_info(hwnd)
            return [(hwnd, title or tgt.get("title", ""), pid,
                     pname or tgt.get("process", ""))]
    return []


_last_protected_log = 0.0


def do_move(cfg, verbose=True):
    global _last_protected_log
    rect = target_rect(cfg)
    if not rect:
        if verbose:
            log("虚拟屏尚未就绪，跳过窗口投送")
        return 0
    wins = candidate_windows(cfg)
    if not wins:
        if verbose:
            log("未找到匹配窗口（关键词: %s）；可用 11_PICK_WINDOW.bat 拾取" % cfg["title_keywords"])
        return 0
    done = 0
    limit = max(1, int(cfg["max_windows"]))
    x, y, w, h = rect
    for hwnd, title, pid, pname in wins[:limit]:
        cur = L.window_rect(hwnd)
        in_place = bool(
            cur and abs(cur[0] - x) < 24 and abs(cur[1] - y) < 24
            and abs(cur[2] - w) < 40 and abs(cur[3] - h) < 40
        )
        if in_place:
            continue
        ok = place_window(hwnd, rect, cfg)
        log("投送窗口 [%s] %s -> (%d,%d) %dx%d  %s" % (
            pname, title[:40], x, y, w, h, "成功" if ok else "失败",
        ))
        if not ok and L.window_is_protected(hwnd):
            # 宿主每 2 秒扫一次，这里节流，避免日志被刷爆
            if time.time() - _last_protected_log > 60:
                log("!! 此窗口以管理员权限运行，普通权限被 UIPI 拦截（拒绝访问）。")
                log("!! 请改用 1_START_ADMIN.bat 启动管理员宿主。")
                _last_protected_log = time.time()
        else:
            done += 1
    return done


def move_hotkey_window(hwnd, back=False):
    """热键：把指定窗口投到虚拟屏 / 送回主屏。"""
    cfg = load_config()
    if back:
        rect = primary_rect()
    else:
        rect = target_rect(cfg)
    if not rect:
        log("热键失败：虚拟屏未就绪")
        return False
    if back:
        L.move_window_to(hwnd, rect[0] + 60, rect[1] + 60,
                         min(1280, rect[2] - 120), min(720, rect[3] - 120),
                         borderless=False, maximize=False)
        log("窗口已送回主屏")
        return True
    ok = place_window(hwnd, rect, cfg)
    title, pid, pname = window_info(hwnd)
    if ok:
        save_target(hwnd, title, pname)
    log("热键投送 [%s] %s -> (%d,%d) %dx%d  %s" % (
        pname, title[:40], rect[0], rect[1], rect[2], rect[3],
        "成功" if ok else "失败",
    ))
    return bool(ok)


def cmd_move(args):
    cfg = load_config()
    rect = target_rect(cfg)
    if not rect:
        print("虚拟屏未点亮，请先运行 1_START.bat")
        return 1
    print("虚拟屏投放区域: (%d,%d) %dx%d" % rect)
    print("匹配关键词: %s" % cfg["title_keywords"])
    tgt = load_target()
    if tgt:
        print("已记住的窗口: 0x%X  %s" % (int(tgt["hwnd"]), tgt.get("title", "")))
    n = do_move(cfg)
    print("本次投送 %d 个窗口。" % n)
    if n == 0:
        print("提示：用 11_PICK_WINDOW.bat 拾取目标窗口，或 3_LIST_WINDOWS.bat 查标题。")
    return 0


def cmd_pick(args):
    """倒计时内让用户激活目标窗口，然后记住它并立即投送。"""
    seconds = max(2, int(args.seconds or 8))
    print("=" * 60)
    print(" 窗口拾取：请在 %d 秒内点击 / 切换到要投送的窗口" % seconds)
    print("（例如抖音直播伴侣的「画面预览」窗口，或伴侣主窗口）")
    print("=" * 60)
    baseline = L.foreground_window()
    picked = None
    for i in range(seconds, 0, -1):
        hwnd = L.foreground_window()
        if hwnd and hwnd != baseline and L.is_window_visible(hwnd):
            title, pid, pname = window_info(hwnd)
            if title and hwnd not in (0,):
                picked = (hwnd, title, pid, pname)
                break
        print("  %2d 秒 ... 当前前台: %s" % (i, window_info(hwnd)[0][:44] or "(无标题)"), end="\r")
        time.sleep(1)
    print(" " * 70)
    if not picked:
        print("没有捕捉到切换窗口。请重新运行，并在倒计时内点一下目标窗口。")
        print("也可以直接按热键 Ctrl+Alt+V 投送当前窗口。")
        return 1
    hwnd, title, pid, pname = picked
    save_target(hwnd, title, pname)
    print("已记住目标窗口:")
    print("  HWND    : 0x%X" % (hwnd & 0xFFFFFFFF))
    print("  标题    : %s" % title[:80])
    print("  进程    : %s" % pname)
    rect = target_rect(load_config())
    if rect:
        ok = place_window(hwnd, rect, load_config())
        print("  投送    : (%d,%d) %dx%d  %s" % (
            rect[0], rect[1], rect[2], rect[3], "成功" if ok else "失败",
        ))
    else:
        print("  提示    : 虚拟屏未点亮，先运行 1_START.bat；目标已保存，之后会自动投送。")
    print("\n以后即使窗口标题变化，宿主也会按这个窗口句柄持续跟踪。")
    print("想换窗口：重新运行本脚本；想清除：删除 logs\\target.json。")
    return 0


def cmd_modes(args):
    name = L.find_vdd_display_name()
    if not name:
        print("虚拟屏未点亮，请先运行 1_START.bat")
        return 1
    modes = L.list_modes(name)
    portrait = [(w, h, hz) for w, h, hz, bpp in modes if h > w]
    print("设备 %s 共 %d 种模式。" % (name, len(modes)))
    if portrait:
        print("竖屏模式（已生效）:")
        for w, h, hz in portrait:
            print("   %dx%d @ %dHz" % (w, h, hz))
    else:
        print("竖屏模式：暂无。驱动默认只提供横屏分辨率。")
        print("           要真正变成 1080x1920，请以管理员运行 9_PORTRAIT.bat。")
    if args.all:
        print("\n全部模式:")
        for w, h, hz, bpp in modes:
            print("   %5d x %-5d @ %-3dHz" % (w, h, hz))
    cur = L.current_mode(name)
    if cur:
        print("\n当前: %dx%d @ %dHz" % (cur.dmPelsWidth, cur.dmPelsHeight, cur.dmDisplayFrequency))
    return 0


def cmd_setmode(args):
    cfg = load_config()
    w = args.width or cfg["width"]
    h = args.height or cfg["height"]
    hz = args.hz or cfg["hz"]
    code, msg = L.set_display_mode(w, h, hz)
    print("设置 %dx%d@%dHz -> %s (code=%d)" % (w, h, hz, msg, code))
    if code != L.DISP_CHANGE_SUCCESSFUL and h > w:
        print("驱动默认不提供竖屏分辨率。请以管理员身份运行 9_PORTRAIT.bat 添加自定义模式。")
        print("或先用横屏 + config.ini 的 portrait_box = 1 做 9:16 居中布局。")
    return 0 if code == L.DISP_CHANGE_SUCCESSFUL else 1


def cmd_add(args):
    """仅调试：加一块虚拟屏后立即退出（没有保活会很快掉线）。"""
    v = L.VDD()
    v.open()
    idx = v.add()
    print("已添加虚拟显示器，驱动索引 %s。此命令不含保活，长时间直播请运行 1_START.bat。" % idx)
    v.close()
    return 0


def unplug_all(v):
    """拔出全部虚拟屏。

    实测要点：打开句柄后必须先 VERSION + UPDATE 建立驱动会话，且要先移除
    索引 0（工具只点亮这一块）。降序批量移除在本机 VDD 0.45 上会被忽略。
    """
    try:
        v.version()
    except Exception:
        pass
    try:
        v.update()
    except Exception:
        pass
    for idx in range(8):
        try:
            v.remove(idx)
        except Exception:
            pass
        time.sleep(0.12)
        if not L.find_vdd_display_name():
            return True
    time.sleep(0.4)
    return L.find_vdd_display_name() is None


def cmd_remove(args):
    v = L.VDD()
    v.open()
    try:
        ok = unplug_all(v)
        time.sleep(0.3)
        still = L.find_vdd_display_name() is not None
    finally:
        v.close()
    ok = ok and not still
    print("虚拟屏已移除。" if ok else "移除指令已发送，但系统仍报告虚拟屏存在；重启电脑即可清除。")
    return 0 if ok else 1


def wait_for_vdd(timeout=20.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if L.find_vdd_display_name():
            return True
        time.sleep(0.25)
    return False


def cmd_host(args):
    cfg = load_config()
    os.makedirs(LOG_DIR, exist_ok=True)
    try:
        if os.path.exists(STOP_FLAG):
            os.remove(STOP_FLAG)
    except Exception:
        pass
    lock = L.acquire_singleton()
    if not lock:
        log("检测到已有保活宿主在运行，本次启动退出（虚拟屏不会重复添加）。")
        return 0

    try:
        admin = bool(L.ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        admin = False
    try:
        with open(HOST_INFO, "w", encoding="utf-8") as f:
            json.dump({"admin": admin, "pid": os.getpid(),
                       "started": time.strftime("%Y-%m-%d %H:%M:%S")}, f)
        log("宿主权限级别: %s" % ("管理员 (High)" if admin else "普通 (Medium)"))
    except Exception:
        pass

    log("=" * 56)
    log("虚拟显示器保活宿主启动")
    log("目标模式: %dx%d@%dHz | 自动投送: %s | 方式: %s" % (
        cfg["width"], cfg["height"], cfg["hz"],
        "开" if cfg["auto_move"] else "关", cfg["mode"],
    ))
    v = L.VDD()
    try:
        path = v.open()
        log("已连接驱动设备: %s" % path)
        try:
            log("驱动 minor 版本: %s" % v.version())
        except Exception:
            pass
    except Exception as e:
        log("启动失败: %s" % e)
        return 1

    own_index = None
    if not L.find_vdd_display_name():
        idx = v.add()
        own_index = idx
        log("已添加虚拟显示器，驱动索引 %s" % idx)
        if not wait_for_vdd():
            log("警告：系统 20 秒内未识别到虚拟屏，可能需要重启电脑或重装驱动。")
    else:
        log("虚拟显示器已存在，接管保活。")

    try:
        code, msg = L.set_display_mode(cfg["width"], cfg["height"], cfg["hz"])
        log("分辨率设置: %dx%d@%dHz -> %s (code=%d)" % (
            cfg["width"], cfg["height"], cfg["hz"], msg, code,
        ))
        if code != L.DISP_CHANGE_SUCCESSFUL and cfg["height"] > cfg["width"]:
            log("警告：驱动尚未加载竖屏模式。请右键管理员运行 9_PORTRAIT.bat，然后重启一次电脑。")
    except Exception as e:
        log("分辨率设置异常（不影响使用）: %s" % e)

    rect = L.vdd_screen_rect()
    if rect:
        log("虚拟屏桌面坐标: (%d,%d) %dx%d" % rect)
    log("保活中…… 请保持宿主运行；用 4_STOP.bat 可停止并拔出虚拟屏。")

    last_move = 0.0
    fails = 0
    if cfg.get("hotkey"):
        start_hotkey_listener()
    try:
        while True:
            if os.path.exists(STOP_FLAG):
                log("收到停止信号（4_STOP.bat），正在关闭虚拟屏……")
                try:
                    os.remove(STOP_FLAG)
                except Exception:
                    pass
                break
            try:
                v.update()
                fails = 0
            except Exception as e:
                fails += 1
                log("保活指令异常(%d/10): %s" % (fails, e))
                if fails >= 10:
                    log("连续失败，宿主退出。")
                    break
            force_move = False
            if os.path.exists(MOVE_NOW):
                try:
                    os.remove(MOVE_NOW)
                except Exception:
                    pass
                force_move = True
            if force_move or (cfg["auto_move"]
                              and time.time() - last_move >= cfg["poll_seconds"]):
                try:
                    do_move(cfg, verbose=False)
                except Exception as e:
                    log("窗口投送异常: %s" % e)
                last_move = time.time()
            time.sleep(0.06)
    except KeyboardInterrupt:
        log("收到 Ctrl+C，正在关闭虚拟屏……")
    finally:
        # 无论这块屏是本进程添加的、还是接管自上一个宿主，退出时都显式拔出。
        # 实测 Windows 11 + VDD 0.45 在停止 ping 后仍可能把显示器留在系统里，
        # 只靠"没人 ping 就自动掉线"不够可靠，会让 4_STOP.bat 看起来没生效。
        try:
            ok = unplug_all(v)
            log("已拔出全部虚拟显示器" if ok else "拔出未完全生效，重启可清除")
        except Exception as e:
            log("清理异常: %s" % e)
        v.close()
        try:
            if os.path.isfile(HOST_INFO):
                os.remove(HOST_INFO)
        except Exception:
            pass
        log("宿主已退出。")
    return 0


def main():
    p = argparse.ArgumentParser(description="虚拟显示器一键工具")
    sub = p.add_subparsers(dest="cmd")

    sub.add_parser("check", help="仅检测驱动是否可用（退出码 0/1）")
    sub.add_parser("status", help="查看驱动与虚拟屏状态")
    sub.add_parser("screens", help="列出所有显示器")
    sub.add_parser("windows", help="列出所有可见窗口")
    sub.add_parser("move", help="手动投送预览窗口到虚拟屏一次")
    sub.add_parser("add", help="[调试] 添加一块虚拟屏（无保活）")
    sub.add_parser("remove", help="移除全部虚拟屏")
    sub.add_parser("host", help="启动常驻保活宿主")

    k = sub.add_parser("modes", help="列出驱动支持的分辨率")
    k.add_argument("--all", action="store_true", help="打印全部模式")

    pk = sub.add_parser("pick", help="交互式拾取目标窗口并记住")
    pk.add_argument("--seconds", type=int, default=8, help="等待秒数，默认 8")

    q = sub.add_parser("setmode", help="设置虚拟屏分辨率/刷新率")
    q.add_argument("--width", type=int)
    q.add_argument("--height", type=int)
    q.add_argument("--hz", type=int)

    args = p.parse_args()
    if not args.cmd:
        args.cmd = "status"

    table = {
        "check": cmd_check,
        "status": cmd_status,
        "screens": cmd_screens,
        "windows": cmd_windows,
        "move": cmd_move,
        "pick": cmd_pick,
        "modes": cmd_modes,
        "setmode": cmd_setmode,
        "add": cmd_add,
        "remove": cmd_remove,
        "host": cmd_host,
    }
    try:
        return table[args.cmd](args)
    except Exception as e:
        log("错误: %s: %s" % (type(e).__name__, e))
        if args.cmd == "check":
            return 1
        return 2


if __name__ == "__main__":
    sys.exit(main())
