# -*- coding: utf-8 -*-
"""
vdd_lib.py -- Parsec VDD 虚拟显示器控制库（纯标准库 / ctypes，无需编译）

实现内容：
  1. 打开 Parsec VDD 驱动设备接口并发送 IOCTL（ADD / REMOVE / UPDATE / VERSION）
  2. 枚举显示器、读取虚拟屏坐标、设置分辨率与刷新率
  3. 枚举顶层窗口、把指定窗口移动到虚拟显示器并铺满 / 去边框
  4. 命名互斥体，防止多个保活宿主同时运行

适用：Windows 10 / 11 64 位，Parsec VDD 0.41 / 0.45 驱动。
参考：https://github.com/nomi-san/parsec-vdd  (core/parsec-vdd.h, BSD-2-Clause)
"""
from __future__ import annotations

import ctypes
import os
import time
from ctypes import wintypes

IS_64BIT = ctypes.sizeof(ctypes.c_void_p) == 8

# ------------------------------------------------------------------ 常量
GENERIC_READ            = 0x80000000
GENERIC_WRITE           = 0x40000000
FILE_SHARE_READ         = 0x00000001
FILE_SHARE_WRITE        = 0x00000002
OPEN_EXISTING           = 3
FILE_ATTRIBUTE_NORMAL   = 0x00000080
FILE_FLAG_OVERLAPPED    = 0x40000000
FILE_FLAG_NO_BUFFERING  = 0x20000000
FILE_FLAG_WRITE_THROUGH = 0x80000000
INVALID_HANDLE_VALUE    = ctypes.c_void_p(-1).value
ERROR_IO_PENDING        = 997
ERROR_ALREADY_EXISTS    = 183

IOCTL_VDD_ADD     = 0x0022E004
IOCTL_VDD_REMOVE  = 0x0022A008
IOCTL_VDD_UPDATE  = 0x0022A00C
IOCTL_VDD_VERSION = 0x0022E010

VDD_ADAPTER_GUID = "{00b41627-04c4-429e-a26e-0265cf50c8fa}"
VDD_CLASS_GUID   = "{4d36e968-e325-11ce-bfc1-08002be10318}"
VDD_HARDWARE_ID  = "Root\\Parsec\\VDA"
VDD_MONITOR_ID   = "PSCCDD0"
VDD_MONITOR_NAME = "ParsecVDA"

CM_GET_DEVICE_INTERFACE_LIST_PRESENT = 0
CR_SUCCESS = 0

PROCESS_QUERY_LIMITED_INFORMATION = 0x1000

ENUM_CURRENT_SETTINGS  = 0xFFFFFFFF
DM_POSITION            = 0x00000020
DM_BITSPERPEL          = 0x00040000
DM_PELSWIDTH           = 0x00080000
DM_PELSHEIGHT          = 0x00100000
DM_DISPLAYFREQUENCY    = 0x00400000
CDS_TEST               = 0x00000002
CDS_UPDATEREGISTRY     = 0x00000001
CDS_NORESET            = 0x10000000
CDS_RESET              = 0x40000000
DISP_CHANGE_SUCCESSFUL = 0
MONITORINFOF_PRIMARY   = 0x00000001
DISPLAY_DEVICE_ATTACHED_TO_DESKTOP = 0x00000001

GWL_STYLE        = -16
SW_RESTORE       = 9
SW_MAXIMIZE      = 3
HWND_TOP         = 0
SWP_SHOWWINDOW   = 0x0040
SWP_FRAMECHANGED = 0x0020
SWP_NOZORDER     = 0x0004
SWP_NOACTIVATE   = 0x0010

WS_BORDER       = 0x00800000
WS_DLGFRAME     = 0x00400000
WS_THICKFRAME   = 0x00040000
WS_SYSMENU      = 0x00080000
WS_MINIMIZEBOX  = 0x00020000
WS_MAXIMIZEBOX  = 0x00010000
WS_CAPTION      = 0x00C00000

# ------------------------------------------------------------------ DLL 与基础类型
_k32 = ctypes.WinDLL("kernel32", use_last_error=True)
_u32 = ctypes.WinDLL("user32", use_last_error=True)
_cfg = ctypes.WinDLL("cfgmgr32", use_last_error=True)

HMONITOR = ctypes.c_void_p
HDC      = ctypes.c_void_p
LPARAM_T = ctypes.c_ssize_t


class GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", ctypes.c_uint32),
        ("Data2", ctypes.c_uint16),
        ("Data3", ctypes.c_uint16),
        ("Data4", ctypes.c_ubyte * 8),
    ]


class OVERLAPPED(ctypes.Structure):
    _fields_ = [
        ("Internal", ctypes.c_void_p),
        ("InternalHigh", ctypes.c_void_p),
        ("Offset", wintypes.DWORD),
        ("OffsetHigh", wintypes.DWORD),
        ("hEvent", wintypes.HANDLE),
    ]


class POINTL(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


def make_guid(text):
    s = text.strip().strip("{}")
    a, b, c, d, e = s.split("-")
    g = GUID()
    g.Data1 = int(a, 16)
    g.Data2 = int(b, 16)
    g.Data3 = int(c, 16)
    g.Data4 = (ctypes.c_ubyte * 8)(*bytes.fromhex(d + e))
    return g


# ---- cfgmgr32：枚举设备接口（比 SetupDi 简单且无需 detail 结构体对齐处理）
_cfg.CM_Get_Device_Interface_List_SizeW.argtypes = [
    ctypes.POINTER(wintypes.ULONG), ctypes.POINTER(GUID),
    ctypes.c_wchar_p, wintypes.ULONG,
]
_cfg.CM_Get_Device_Interface_List_SizeW.restype = wintypes.ULONG
_cfg.CM_Get_Device_Interface_ListW.argtypes = [
    ctypes.POINTER(GUID), ctypes.c_wchar_p,
    ctypes.c_wchar_p, wintypes.ULONG, wintypes.ULONG,
]
_cfg.CM_Get_Device_Interface_ListW.restype = wintypes.ULONG

_k32.CreateFileW.argtypes = [
    wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
    wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE,
]
_k32.CreateFileW.restype = wintypes.HANDLE
_k32.CreateEventW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR]
_k32.CreateEventW.restype = wintypes.HANDLE
_k32.CloseHandle.argtypes = [wintypes.HANDLE]
_k32.CloseHandle.restype = wintypes.BOOL
_k32.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
_k32.CreateMutexW.restype = wintypes.HANDLE
_k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
_k32.OpenProcess.restype = wintypes.HANDLE
_k32.QueryFullProcessImageNameW.argtypes = [
    wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD),
]
_k32.QueryFullProcessImageNameW.restype = wintypes.BOOL
_k32.DeviceIoControl.argtypes = [
    wintypes.HANDLE, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD,
    ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD),
    ctypes.POINTER(OVERLAPPED),
]
_k32.DeviceIoControl.restype = wintypes.BOOL
_k32.GetOverlappedResultEx.argtypes = [
    wintypes.HANDLE, ctypes.POINTER(OVERLAPPED),
    ctypes.POINTER(wintypes.DWORD), wintypes.DWORD, wintypes.BOOL,
]
_k32.GetOverlappedResultEx.restype = wintypes.BOOL


def list_device_interfaces(guid_text):
    """返回该设备接口类下所有已存在设备的 CreateFile 路径。"""
    g = make_guid(guid_text)
    need = wintypes.ULONG(0)
    r = _cfg.CM_Get_Device_Interface_List_SizeW(
        ctypes.byref(need), ctypes.byref(g), None,
        CM_GET_DEVICE_INTERFACE_LIST_PRESENT,
    )
    if r != CR_SUCCESS or need.value == 0:
        return []
    size = need.value + 4
    buf = ctypes.create_unicode_buffer(size)
    r = _cfg.CM_Get_Device_Interface_ListW(
        ctypes.byref(g), None, buf, size,
        CM_GET_DEVICE_INTERFACE_LIST_PRESENT,
    )
    if r != CR_SUCCESS:
        return []
    data = ctypes.string_at(ctypes.addressof(buf), size * 2).decode(
        "utf-16-le", errors="ignore",
    )
    return [p for p in data.split("\x00") if p and p.startswith("\\\\?\\")]


class VddError(Exception):
    pass


class VDD(object):
    """Parsec VDD 设备句柄封装。"""

    def __init__(self):
        self.handle = None
        self.path = None

    def open(self):
        paths = list_device_interfaces(VDD_ADAPTER_GUID)
        # 兼容回退：部分系统上设备接口枚举会失败，直接按 ROOT\DISPLAY\000N 猜测
        for i in range(16):
            paths.append("\\\\?\\root#display#%04d#%s" % (i, VDD_ADAPTER_GUID))
        last_err = 0
        for p in paths:
            h = _k32.CreateFileW(
                p, GENERIC_READ | GENERIC_WRITE,
                FILE_SHARE_READ | FILE_SHARE_WRITE, None, OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED
                | FILE_FLAG_NO_BUFFERING | FILE_FLAG_WRITE_THROUGH,
                None,
            )
            if h and h != INVALID_HANDLE_VALUE:
                self.handle = h
                self.path = p
                # 官方 Core.OpenHandle() 在拿到句柄后立刻 Update 建立驱动会话。
                # 少了这一步，后续 ADD / REMOVE 可能被驱动静默忽略。
                try:
                    self.update()
                except Exception:
                    pass
                return p
            last_err = ctypes.get_last_error()
        raise VddError(
            "无法打开虚拟显示器驱动设备 (Win32错误 %s)。"
            "请确认 Parsec VDD 驱动已安装，必要时以管理员运行 5_INSTALL_DRIVER.bat 并重启电脑。"
            % last_err
        )

    def ioctl(self, code, data=b""):
        if not self.handle:
            raise VddError("设备句柄未打开")
        inbuf = ctypes.create_string_buffer(32)
        if data:
            ctypes.memmove(inbuf, data, min(len(data), 32))
        out = wintypes.DWORD(0)
        ov = OVERLAPPED()
        ev = _k32.CreateEventW(None, True, False, None)
        if not ev:
            raise VddError("CreateEventW 失败: %s" % ctypes.get_last_error())
        ov.hEvent = ev

        ok = _k32.DeviceIoControl(
            self.handle, code, inbuf, 32, ctypes.byref(out), 4,
            None, ctypes.byref(ov),
        )
        if not ok and ctypes.get_last_error() != ERROR_IO_PENDING:
            err = ctypes.get_last_error()
            _k32.CloseHandle(ev)
            raise VddError("DeviceIoControl 失败: %s" % err)

        transferred = wintypes.DWORD(0)
        done = _k32.GetOverlappedResultEx(
            self.handle, ctypes.byref(ov), ctypes.byref(transferred), 5000, False,
        )
        _k32.CloseHandle(ev)
        if not done:
            return -1
        return out.value

    def version(self):
        return self.ioctl(IOCTL_VDD_VERSION)

    def update(self):
        """保活 ping。必须持续调用（<100ms 一次），否则虚拟屏会被驱动自动拔出。"""
        return self.ioctl(IOCTL_VDD_UPDATE)

    def add(self):
        idx = self.ioctl(IOCTL_VDD_ADD)
        self.update()
        return idx

    def remove(self, index):
        # 官方 Core.RemoveDisplay(): input[0]=0, input[1]=index&0xFF
        r = self.ioctl(IOCTL_VDD_REMOVE, bytes([0, index & 0xFF]))
        self.update()
        return r

    def close(self):
        if self.handle:
            _k32.CloseHandle(self.handle)
            self.handle = None


def acquire_singleton(name="VDD_Toolkit_Host_Singleton"):
    """返回互斥体句柄；已有实例在跑则返回 None。"""
    h = _k32.CreateMutexW(None, False, name)
    if not h:
        return None
    if ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
        _k32.CloseHandle(h)
        return None
    return h


def singleton_exists(name="VDD_Toolkit_Host_Singleton"):
    """只读检测宿主是否已在运行（会立刻释放自己创建的句柄）。"""
    h = _k32.CreateMutexW(None, False, name)
    if not h:
        return False
    exists = ctypes.get_last_error() == ERROR_ALREADY_EXISTS
    _k32.CloseHandle(h)
    return exists


# ------------------------------------------------------------------ 显示器
class DISPLAY_DEVICEW(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD),
        ("DeviceName", ctypes.c_wchar * 32),
        ("DeviceString", ctypes.c_wchar * 128),
        ("StateFlags", wintypes.DWORD),
        ("DeviceID", ctypes.c_wchar * 128),
        ("DeviceKey", ctypes.c_wchar * 128),
    ]


class MONITORINFOEXW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("rcMonitor", wintypes.RECT),
        ("rcWork", wintypes.RECT),
        ("dwFlags", wintypes.DWORD),
        ("szDevice", ctypes.c_wchar * 32),
    ]


class DEVMODE_D(ctypes.Structure):
    _fields_ = [
        ("dmOrientation", ctypes.c_short),
        ("dmPaperSize", ctypes.c_short),
        ("dmPaperLength", ctypes.c_short),
        ("dmPaperWidth", ctypes.c_short),
    ]


# 注意：wingdi.h 中该 union 只有 8 字节（4 个 short 与 1 个 POINTL 重叠）。
# dmDisplayOrientation / dmDisplayFixedOutput 是后续版本追加在结构末尾的，
# 不属于这个 union。多算 4 字节会让后面所有显示字段整体错位。
class DEVMODE_U(ctypes.Union):
    _fields_ = [("d", DEVMODE_D), ("p", POINTL)]


class DEVMODEW(ctypes.Structure):
    _fields_ = [
        ("dmDeviceName", ctypes.c_wchar * 32),
        ("dmSpecVersion", ctypes.c_uint16),
        ("dmDriverVersion", ctypes.c_uint16),
        ("dmSize", ctypes.c_uint16),
        ("dmDriverExtra", ctypes.c_uint16),
        ("dmFields", wintypes.DWORD),
        ("u", DEVMODE_U),
        ("dmScale", ctypes.c_short),
        ("dmCopies", ctypes.c_short),
        ("dmDefaultSource", ctypes.c_short),
        ("dmPrintQuality", ctypes.c_short),
        ("dmColor", ctypes.c_short),
        ("dmDuplex", ctypes.c_short),
        ("dmYResolution", ctypes.c_short),
        ("dmTTOption", ctypes.c_short),
        ("dmCollate", ctypes.c_short),
        ("dmFormName", ctypes.c_wchar * 32),
        ("dmLogPixels", ctypes.c_uint16),
        ("dmBitsPerPel", wintypes.DWORD),
        ("dmPelsWidth", wintypes.DWORD),
        ("dmPelsHeight", wintypes.DWORD),
        ("dmDisplayFlags", wintypes.DWORD),
        ("dmDisplayFrequency", wintypes.DWORD),
    ]
    # 实测 Windows 10/11 的 EnumDisplaySettingsW 回写 dmSize = 188，
    # 即结构到 dmDisplayFrequency 为止。不要追加 ICM / Panning 字段，
    # 否则 dmSize 变为 220+ 会与系统不一致。



_u32.EnumDisplayDevicesW.argtypes = [
    wintypes.LPCWSTR, wintypes.DWORD, ctypes.POINTER(DISPLAY_DEVICEW), wintypes.DWORD,
]
_u32.EnumDisplayDevicesW.restype = wintypes.BOOL
_u32.EnumDisplaySettingsW.argtypes = [
    wintypes.LPCWSTR, wintypes.DWORD, ctypes.POINTER(DEVMODEW),
]
_u32.EnumDisplaySettingsW.restype = wintypes.BOOL
_u32.ChangeDisplaySettingsExW.argtypes = [
    wintypes.LPCWSTR, ctypes.POINTER(DEVMODEW), wintypes.HWND,
    wintypes.DWORD, ctypes.c_void_p,
]
_u32.ChangeDisplaySettingsExW.restype = ctypes.c_long
_u32.GetMonitorInfoW.argtypes = [HMONITOR, ctypes.POINTER(MONITORINFOEXW)]
_u32.GetMonitorInfoW.restype = wintypes.BOOL

MONITORENUMPROC = ctypes.WINFUNCTYPE(
    wintypes.BOOL, HMONITOR, HDC, ctypes.POINTER(wintypes.RECT), LPARAM_T,
)
_u32.EnumDisplayMonitors.argtypes = [
    HDC, ctypes.POINTER(wintypes.RECT), MONITORENUMPROC, LPARAM_T,
]
_u32.EnumDisplayMonitors.restype = wintypes.BOOL


def display_devices():
    out = []
    i = 0
    while True:
        d = DISPLAY_DEVICEW()
        d.cb = ctypes.sizeof(DISPLAY_DEVICEW)
        if not _u32.EnumDisplayDevicesW(None, i, ctypes.byref(d), 0):
            break
        out.append(d)
        i += 1
    return out


def find_vdd_display_name():
    """返回虚拟显示器对应的 Windows 显示设备名（如 DISPLAY19）；未找到返回 None。

    实测 Windows 11 上报两层信息：
      顶层 EnumDisplayDevices: DeviceString="Parsec Virtual Display Adapter",
                               DeviceID="Root\\Parsec\\VDA", 连接时 StateFlags=1
      monitor 层            : DeviceID="MONITOR\\PSCCDD0\\..."
    两种都做匹配，避免只认 EDID 名而漏判。
    """
    for d in display_devices():
        blob = (d.DeviceString + " " + d.DeviceID).upper()
        if ("PARSEC" in blob or VDD_MONITOR_ID in blob
                or VDD_MONITOR_NAME.upper() in blob):
            if d.StateFlags & DISPLAY_DEVICE_ATTACHED_TO_DESKTOP:
                return d.DeviceName
    # 回退：部分系统顶层名称被改写，用 monitor 级 EDID 标识精确定位
    for m in monitors():
        dd = DISPLAY_DEVICEW()
        dd.cb = ctypes.sizeof(DISPLAY_DEVICEW)
        if _u32.EnumDisplayDevicesW(m[0], 0, ctypes.byref(dd), 0):
            blob = (dd.DeviceString + " " + dd.DeviceID).upper()
            if VDD_MONITOR_ID in blob or VDD_MONITOR_NAME.upper() in blob:
                return m[0]
    return None


def monitors():
    """返回 [(设备名, left, top, right, bottom, 是否主屏), ...]"""
    found = []

    def cb(hmon, hdc, lprc, data):
        mi = MONITORINFOEXW()
        mi.cbSize = ctypes.sizeof(MONITORINFOEXW)
        if _u32.GetMonitorInfoW(hmon, ctypes.byref(mi)):
            r = mi.rcMonitor
            found.append((
                mi.szDevice, r.left, r.top, r.right, r.bottom,
                bool(mi.dwFlags & MONITORINFOF_PRIMARY),
            ))
        return True

    fn = MONITORENUMPROC(cb)
    _u32.EnumDisplayMonitors(None, None, fn, 0)
    return found


def vdd_screen_rect():
    """返回虚拟显示器的 (x, y, width, height)，没有则 None。"""
    name = find_vdd_display_name()
    if not name:
        return None
    for dev, l, t, r, b, primary in monitors():
        if dev.upper() == name.upper():
            return (l, t, r - l, b - t)
    return None


def current_mode(device_name):
    dm = DEVMODEW()
    dm.dmSize = ctypes.sizeof(DEVMODEW)
    if not _u32.EnumDisplaySettingsW(device_name, ENUM_CURRENT_SETTINGS, ctypes.byref(dm)):
        return None
    return dm


def set_display_mode(width=1920, height=1080, hz=60, device_name=None):
    """把虚拟显示器设为指定分辨率 / 刷新率，返回 (状态码, 说明)。"""
    dev = device_name or find_vdd_display_name()
    if not dev:
        return (-1, "未检测到虚拟显示器，请先启动保活宿主")
    dm = current_mode(dev)
    if dm is None:
        return (-1, "无法读取当前显示模式: %s" % dev)
    dm.dmPelsWidth = int(width)
    dm.dmPelsHeight = int(height)
    if hz:
        dm.dmDisplayFrequency = int(hz)
    dm.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT
    if hz:
        dm.dmFields |= DM_DISPLAYFREQUENCY

    test = _u32.ChangeDisplaySettingsExW(dev, ctypes.byref(dm), None, CDS_TEST, None)
    if test != DISP_CHANGE_SUCCESSFUL:
        return (test, "驱动不支持 %dx%d@%d (CDS_TEST=%d)，可改用 1920x1080@60" % (width, height, hz, test))
    r = _u32.ChangeDisplaySettingsExW(
        dev, ctypes.byref(dm), None, CDS_UPDATEREGISTRY | CDS_NORESET, None,
    )
    _u32.ChangeDisplaySettingsExW(None, None, None, 0, None)
    return (r, "OK" if r == DISP_CHANGE_SUCCESSFUL else "ChangeDisplaySettingsEx 返回 %d" % r)


# ------------------------------------------------------------------ 窗口
WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, LPARAM_T)
_u32.EnumWindows.argtypes = [WNDENUMPROC, LPARAM_T]
_u32.EnumWindows.restype = wintypes.BOOL
_u32.IsWindowVisible.argtypes = [wintypes.HWND]
_u32.IsWindowVisible.restype = wintypes.BOOL
_u32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
_u32.GetWindowTextLengthW.restype = ctypes.c_int
_u32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
_u32.GetWindowTextW.restype = ctypes.c_int
_u32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
_u32.GetWindowThreadProcessId.restype = wintypes.DWORD
_u32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
_u32.GetWindowRect.restype = wintypes.BOOL
_u32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
_u32.ShowWindow.restype = wintypes.BOOL
_u32.SetWindowPos.argtypes = [
    wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
    ctypes.c_int, ctypes.c_int, wintypes.UINT,
]
_u32.SetWindowPos.restype = wintypes.BOOL
_u32.SetForegroundWindow.argtypes = [wintypes.HWND]
_u32.SetForegroundWindow.restype = wintypes.BOOL
_u32.BringWindowToTop.argtypes = [wintypes.HWND]
_u32.BringWindowToTop.restype = wintypes.BOOL

if IS_64BIT:
    _u32.GetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
    _u32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
    _u32.SetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
    _u32.SetWindowLongPtrW.restype = ctypes.c_ssize_t
    _get_style = _u32.GetWindowLongPtrW
    _set_style = _u32.SetWindowLongPtrW
else:
    _u32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
    _u32.GetWindowLongW.restype = ctypes.c_long
    _u32.SetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
    _u32.SetWindowLongW.restype = ctypes.c_long
    _get_style = _u32.GetWindowLongW
    _set_style = _u32.SetWindowLongW


def process_name(pid):
    h = _k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not h:
        return ""
    try:
        buf = ctypes.create_unicode_buffer(1024)
        n = wintypes.DWORD(1024)
        if _k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
            return os.path.basename(buf.value)
        return ""
    finally:
        _k32.CloseHandle(h)


def enum_windows():
    """返回 [(hwnd, 标题, pid, 进程名), ...]，仅含有标题且可见的顶层窗口。"""
    out = []

    def cb(hwnd, lparam):
        if not _u32.IsWindowVisible(hwnd):
            return True
        n = _u32.GetWindowTextLengthW(hwnd)
        if n <= 0:
            return True
        buf = ctypes.create_unicode_buffer(n + 1)
        _u32.GetWindowTextW(hwnd, buf, n + 1)
        pid = wintypes.DWORD(0)
        _u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        out.append((hwnd, buf.value, pid.value, process_name(pid.value)))
        return True

    fn = WNDENUMPROC(cb)
    _u32.EnumWindows(fn, 0)
    return out


def match_windows(title_keywords, process_keywords=None):
    """按标题 / 进程名关键词筛选窗口，返回匹配列表。"""
    tk = [k.strip().lower() for k in title_keywords if k.strip()]
    pk = [k.strip().lower() for k in (process_keywords or []) if k.strip()]
    out = []
    for hwnd, title, pid, pname in enum_windows():
        t = title.lower()
        p = (pname or "").lower()
        hit_title = any(k in t for k in tk) if tk else False
        hit_proc = any(k in p for k in pk) if pk else False
        # 有进程关键词时，标题或进程任一命中即可；否则仅按标题
        if pk:
            if hit_title or hit_proc:
                out.append((hwnd, title, pid, pname))
        elif hit_title:
            out.append((hwnd, title, pid, pname))
    return out


def window_is_protected(hwnd):
    """探测目标窗口是否高于本进程完整性级别（UIPI 拦截）。

    抖音直播伴侣及其 MediaSDK_Server.exe 常以「管理员(High)」运行，普通(Medium)
    进程对它调用 SetWindowPos 会返回 ERROR_ACCESS_DENIED(5)，自动投送/热键/拾取
    会全部失效。这里用一组「不改变窗口」的标志做无副作用探测。
    """
    SWP_NOSIZE = 0x0001
    SWP_NOMOVE = 0x0002
    SWP_NOOWNERZORDER = 0x0200
    flags = (SWP_NOSIZE | SWP_NOMOVE | SWP_NOZORDER
             | SWP_NOACTIVATE | SWP_NOOWNERZORDER)
    ctypes.set_last_error(0)
    ok = _u32.SetWindowPos(hwnd, 0, 0, 0, 0, 0, flags)
    return (not ok) and ctypes.get_last_error() == 5


def move_window_to(hwnd, x, y, w, h, borderless=False, maximize=False):
    """把窗口放到指定屏幕坐标。borderless=True 时去掉标题栏/边框以铺满整屏。"""
    _u32.ShowWindow(hwnd, SW_RESTORE)
    if borderless:
        style = _get_style(hwnd, GWL_STYLE)
        style &= ~(WS_CAPTION | WS_THICKFRAME | WS_SYSMENU
                   | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_BORDER | WS_DLGFRAME)
        _set_style(hwnd, GWL_STYLE, style)
    flags = SWP_SHOWWINDOW | SWP_FRAMECHANGED | SWP_NOZORDER | SWP_NOACTIVATE
    if maximize and not borderless:
        # 先把窗口挪到目标屏（保持原尺寸），再让 Windows 按该屏工作区最大化，
        # 这样标题栏仍然保留，直播伴侣自身的按钮/菜单也还能用。
        cur = window_rect(hwnd) or (x, y, min(w, 1280), min(h, 720))
        ok = _u32.SetWindowPos(
            hwnd, HWND_TOP, int(x), int(y), int(cur[2]), int(cur[3]), flags,
        )
        _u32.ShowWindow(hwnd, SW_MAXIMIZE)
        return bool(ok)
    return bool(_u32.SetWindowPos(hwnd, HWND_TOP, int(x), int(y), int(w), int(h), flags))


def window_rect(hwnd):
    r = wintypes.RECT()
    if _u32.GetWindowRect(hwnd, ctypes.byref(r)):
        return (r.left, r.top, r.right - r.left, r.bottom - r.top)
    return None


# ------------------------------------------------------------------ 附加工具
_u32.GetForegroundWindow.argtypes = []
_u32.GetForegroundWindow.restype = wintypes.HWND
_u32.IsWindow.argtypes = [wintypes.HWND]
_u32.IsWindow.restype = wintypes.BOOL
_u32.GetAsyncKeyState.argtypes = [ctypes.c_int]
_u32.GetAsyncKeyState.restype = ctypes.c_short


def list_modes(device_name=None):
    """枚举驱动上报的全部显示模式，返回去重后的 [(w, h, hz, bpp), ...]。

    用于验证自定义竖屏分辨率是否已被驱动加载。
    """
    dev = device_name or find_vdd_display_name()
    if not dev:
        return []
    seen, out = set(), []
    # 不因单次 FALSE 就停：部分 IddCx 驱动会在索引序列中间返回失败，
    # 后面的自定义模式仍然有效。宁可多扫几轮，也不要漏掉竖屏模式。
    for i in range(1024):
        dm = DEVMODEW()
        dm.dmSize = ctypes.sizeof(DEVMODEW)
        if not _u32.EnumDisplaySettingsW(dev, i, ctypes.byref(dm)):
            continue
        key = (dm.dmPelsWidth, dm.dmPelsHeight, dm.dmDisplayFrequency, dm.dmBitsPerPel)
        if key not in seen:
            seen.add(key)
            out.append(key)
    return out


def has_mode(width, height, hz=60, device_name=None):
    return any(m[0] == width and m[1] == height and (not hz or m[2] == hz)
               for m in list_modes(device_name))


def foreground_window():
    return _u32.GetForegroundWindow()


def is_window(hwnd):
    return bool(hwnd) and bool(_u32.IsWindow(hwnd))


def is_window_visible(hwnd):
    return bool(_u32.IsWindowVisible(hwnd))


def key_down(vk):
    """GetAsyncKeyState 高位为 1 表示此刻按下。"""
    return bool(_u32.GetAsyncKeyState(vk) & 0x8000)


# ------------------------------------------------------- 原生全局热键
# GetAsyncKeyState 在没有消息泵的后台线程里不可靠，实测注入按键读不到。
# RegisterHotKey + 线程消息循环才是 Windows 官方的全局热键机制。
class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class MSG(ctypes.Structure):
    _fields_ = [
        ("hwnd", wintypes.HWND),
        ("message", wintypes.UINT),
        ("wParam", ctypes.c_size_t),
        ("lParam", ctypes.c_ssize_t),
        ("time", wintypes.DWORD),
        ("pt", POINT),
    ]


_u32.RegisterHotKey.argtypes = [
    wintypes.HWND, ctypes.c_int, wintypes.UINT, wintypes.UINT,
]
_u32.RegisterHotKey.restype = wintypes.BOOL
_u32.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
_u32.UnregisterHotKey.restype = wintypes.BOOL
_u32.GetMessageW.argtypes = [
    ctypes.POINTER(MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT,
]
_u32.GetMessageW.restype = ctypes.c_int

WM_HOTKEY = 0x0312
MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_NOREPEAT = 0x4000

# 虚拟键：Ctrl / Alt / V / B
VK_CONTROL = 0x11
VK_MENU = 0x12
VK_V = 0x56
VK_B = 0x42


def register_hotkey(hotkey_id, vk):
    mods = MOD_CONTROL | MOD_ALT | MOD_NOREPEAT
    return bool(_u32.RegisterHotKey(None, hotkey_id, mods, vk))


def unregister_hotkey(hotkey_id):
    return bool(_u32.UnregisterHotKey(None, hotkey_id))


def get_message(msg):
    """>0 收到消息；0 = WM_QUIT；-1 = 出错。"""
    return _u32.GetMessageW(ctypes.byref(msg), None, 0, 0)
