# -*- coding: utf-8 -*-
"""以管理员权限启动保活宿主。

背景（实测）：抖音直播伴侣及其 MediaSDK_Server.exe 的「预览画面」窗口以
High 完整性级别（管理员）运行。Windows UIPI 规定普通 Medium 进程不能对
High 窗口调用 SetWindowPos，会返回 ERROR_ACCESS_DENIED(5)。因此普通权限
启动的宿主虽然能点亮虚拟屏，但「自动投送 / 热键 / 拾取窗口」对抖音窗口
全部失效。

本脚本弹一次 UAC，把宿主提升到管理员级别后再常驻，所有窗口操作才生效。
用法：双击 1_START_ADMIN.bat（或由本模块自行 runas 提权）。
"""
from __future__ import annotations

import ctypes
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

RESULT = os.path.join(ROOT, "logs", "admin_host_result.json")
PYW = os.path.join(ROOT, "runtime", "pythonw.exe")


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def become_host():
    """提权后由「本进程」直接常驻为宿主（不再派生子进程）。

    实测：提权进程再 Popen 一个 pythonw 子进程时，父进程一退出子进程就被
    Job Object 回收（pythonw 消失，虚拟屏残留但不保活）。UAC 提权进程本身
    由系统 AppInfo 服务创建，不属于工具会话的 Job，所以它自己进入宿主循环
    才最可靠，同时天然继承 High 完整性。
    """
    import vdd_tool as T
    import portrait_setup as P

    P.stop_host()
    try:
        if os.path.isfile(T.STOP_FLAG):
            os.remove(T.STOP_FLAG)
    except Exception:
        pass
    time.sleep(0.8)
    # 阻塞常驻：内部负责点亮虚拟屏、持续 ping、自动投送窗口、注册全局热键
    return T.cmd_host(None)


def write_result(res):
    os.makedirs(os.path.dirname(RESULT), exist_ok=True)
    with open(RESULT, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)


def main():
    if "--elevated" in sys.argv:
        # 先把结果写给等待中的普通权限父进程，然后本进程直接常驻为宿主
        write_result({
            "admin": True, "ok": True,
            "steps": [
                "已获得管理员权限",
                "管理员宿主由本进程直接常驻（不会被会话回收）",
                "虚拟屏将在数秒内点亮并自动投送「预览画面」窗口",
            ],
        })
        return become_host()

    if is_admin():
        print("  已是管理员，直接以管理员宿主常驻（本窗口可关闭，宿主在后台）……")
        return become_host()

    try:
        if os.path.isfile(RESULT):
            os.remove(RESULT)
    except Exception:
        pass

    script = os.path.abspath(__file__)
    params = '"%s" --elevated' % script
    target = PYW if os.path.isfile(PYW) else sys.executable
    rc = ctypes.windll.shell32.ShellExecuteW(
        None, "runas", target, params, ROOT, 0,
    )
    if rc <= 32:
        print("  [失败] 无法请求管理员权限（UAC 可能被取消，rc=%s）" % rc)
        return 1

    wait = float(os.environ.get("VDD_UAC_WAIT", "90"))
    print(" 已弹出 UAC 授权窗口，请在弹窗里点「是」（最多等 %d 秒）……" % int(wait))
    deadline = time.time() + wait
    while time.time() < deadline:
        if os.path.isfile(RESULT):
            time.sleep(0.4)
            try:
                with open(RESULT, "r", encoding="utf-8") as f:
                    res = json.load(f)
            except Exception as e:
                print("  [失败] 读取结果失败: %s" % e)
                return 1
            for s in res.get("steps", []):
                print("  - " + s)
            print("  [完成] 管理员宿主已就绪，抖音预览窗口可自动投送"
                  if res.get("ok") else "  [未完成] 请查看 logs/host.log")
            # 再确认虚拟屏与目标窗口确实就位（读状态不需要管理员权限）
            try:
                import vdd_lib as L
                import vdd_tool as T
                T.wait_for_vdd(timeout=15.0)
                time.sleep(1.5)
                wins = T.candidate_windows(T.load_config())
                rect = L.vdd_screen_rect()
                if wins and rect:
                    print("  [验证] 虚拟屏 %s | 预览窗口 %s" % (
                        rect, L.window_rect(wins[0][0]),
                    ))
            except Exception:
                pass
            return 0 if res.get("ok") else 1
        time.sleep(0.5)
    print("  [失败] 等待 UAC 授权超时")
    return 1


if __name__ == "__main__":
    sys.exit(main())
