# -*- coding: utf-8 -*-
"""
menu.py -- 虚拟显示器总控台（0_MENU.bat 的入口）

把日常要用的操作集中到一个菜单里，避免记一堆 .bat：
  - 启动/关闭一律用后台静默宿主（pythonw.exe），不需要守着黑色窗口
  - 横竖屏切换、窗口拾取、投送、开机自启、驱动分辨率检查
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import vdd_lib as L  # noqa: E402
import vdd_tool as T  # noqa: E402
import portrait_setup as P  # noqa: E402

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def run_py(script, *args):
    cmd = [sys.executable, os.path.join(HERE, script)] + [str(a) for a in args]
    try:
        return subprocess.run(cmd, cwd=ROOT).returncode
    except Exception as e:
        print("  [错误] 无法运行 %s: %s" % (script, e))
        return 2


def run_bat(name):
    try:
        return subprocess.run(["cmd.exe", "/c", os.path.join(ROOT, name)], cwd=ROOT).returncode
    except Exception as e:
        print("  [错误] 无法运行 %s: %s" % (name, e))
        return 2


def pause():
    try:
        input("\n  按回车返回菜单 ... ")
    except (EOFError, KeyboardInterrupt):
        pass


def header():
    cfg = T.load_config()
    print("\n" + "=" * 68)
    print("  虚拟显示器总控台  |  VDD Toolkit")
    print("=" * 68)

    # 驱动
    try:
        v = L.VDD()
        v.open()
        try:
            ver = v.version()
        except Exception:
            ver = "?"
        v.close()
        drv = "已安装可访问 (minor %s)" % ver
    except Exception:
        drv = "不可用 -> 请以管理员运行 5_INSTALL_DRIVER.bat 并重启"

    name = L.find_vdd_display_name()
    if name:
        dm = L.current_mode(name)
        rect = L.vdd_screen_rect()
        mode = "%dx%d@%dHz" % (
            dm.dmPelsWidth, dm.dmPelsHeight, dm.dmDisplayFrequency,
        ) if dm else "?"
        orient = "竖屏" if (dm and dm.dmPelsHeight > dm.dmPelsWidth) else "横屏"
        if cfg.get("portrait_box"):
            orient += " + 9:16 居中布局"
        pos = "(%d,%d)" % (rect[0], rect[1]) if rect else "?"
        screen = "%s  %s  %s  %s" % (name, mode, orient, pos)
    else:
        screen = "未点亮"

    host = "运行中（后台静默，可关闭本窗口）" if L.singleton_exists() else "未运行"
    tgt = T.load_target()
    target = ("已记住 0x%X  %s" % (int(tgt["hwnd"]), tgt.get("title", "")[:36])
              if tgt else "未设置（按 6 拾取，或按关键词自动匹配）")
    portrait = ("已可用" if L.has_mode(*P.PORTRAIT)
                else "未配置（按 4 一键添加，需 UAC 一次）") if name else "虚拟屏未点亮"

    print("  驱动       : %s" % drv)
    print("  虚拟屏     : %s" % screen)
    print("  保活宿主   : %s" % host)
    print("  目标窗口   : %s" % target)
    print("  竖屏模式   : %s" % portrait)
    try:
        wins = T.candidate_windows(cfg)
        if not wins:
            perm = "尚未找到目标窗口"
        elif L.window_is_protected(wins[0][0]):
            perm = "目标窗口是管理员权限 -> 必须按 [15] 启动管理员宿主！"
        else:
            perm = "普通权限即可投送"
    except Exception:
        perm = "未检测"
    print("  窗口权限   : %s" % perm)
    print("  热键       : Ctrl+Alt+V 投到虚拟屏 / Ctrl+Alt+B 送回主屏")
    print("=" * 68)


MENU = """
   [1] 启动 / 重启虚拟屏（后台静默，无需保持窗口）
   [2] 关闭虚拟屏
   [3] 查看详细状态、显示器坐标

   [4] 切成竖屏 1080x1920（首次需 UAC 授权一次）
   [5] 切回横屏 1920x1080
   [6] 拾取目标窗口（点一下预览窗口就自动记住）
   [7] 立即投送一次
   [8] 列出所有窗口标题
   [9] 清除已记住的目标窗口

  [10] 9:16 居中布局：开 / 关（免权限竖屏替代方案）
  [11] 查看驱动支持的全部分辨率
  [12] 开机自动点亮：开启 / 关闭
  [13] 安装驱动（新电脑首次，管理员）
  [14] 卸载驱动（管理员）
  [15] 以管理员启动宿主（抖音直播伴侣必备，需 UAC 一次）

   [0] 退出
"""


def action_start():
    print("\n 正在重启保活宿主（后台静默）……")
    P.stop_host()
    time.sleep(1.0)
    pid = P.start_host()
    print("  宿主已启动（%s），等待虚拟屏出现……" % ("PID %s" % pid if pid else "桌面 Shell 后台"))
    for _ in range(24):
        time.sleep(0.5)
        if L.find_vdd_display_name():
            break
    time.sleep(1.0)
    cfg = T.load_config()
    P.verify_mode(cfg["width"], cfg["height"])
    print("  完成。可以直接关闭本窗口，虚拟屏会继续工作。")


def action_start_admin():
    print("\n 正在以管理员权限重启宿主（会弹一次 UAC，请在弹窗点「是」）……")
    print(" 只有管理员宿主才能移动抖音直播伴侣的预览窗口。")
    return run_py("admin_host.py")


def action_stop():
    print("\n 正在关闭虚拟屏……")
    P.stop_host()
    if L.find_vdd_display_name():
        run_py("vdd_tool.py", "remove")
    time.sleep(0.8)
    print("  虚拟屏状态: %s" % ("仍在（重启电脑可清除）" if L.find_vdd_display_name() else "已关闭"))


def action_portrait_box():
    path = P.CONFIG_PATH
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    cur = 1 if re.search(r"(?m)^\s*portrait_box\s*=\s*1\b", text) else 0
    new = 0 if cur else 1
    text, n = re.subn(
        r"(?m)^(\s*portrait_box\s*=\s*)\S+",
        lambda m: m.group(1) + str(new), text, count=1,
    )
    if n == 0:
        print("\n  config.ini 里没有 portrait_box 项，请手动添加 portrait_box = %d 到 [window] 段。" % new)
        return
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(text)
    print("\n  9:16 居中布局已%s。" % ("开启" if new else "关闭"))
    if new:
        print("  虚拟屏仍是 1920x1080，但预览窗口会以 9:16 居中放置（左右留黑）。")
        print("  采集端请用「区域采集 / 裁剪」只取中间那块，即可得到 9:16 画面。")
    print("  重新按 [1] 重启宿主后生效。")


def action_autostart():
    import winreg
    key = r"Software\Microsoft\Windows\CurrentVersion\Run"
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key) as k:
            value = winreg.QueryValueEx(k, "VDD-Host")[0]
            on = True
    except OSError:
        on = False
    print("\n  当前开机自启: %s" % ("已开启" if on else "未开启"))
    print("  选择: 1=开启  2=关闭  其他=取消")
    c = input("  > ").strip()
    if c == "1":
        run_py("setup_autostart.py", "install")
    elif c == "2":
        run_py("setup_autostart.py", "remove")


def action_driver():
    print("\n  选择: 1=安装驱动  2=卸载驱动  其他=取消")
    c = input("  > ").strip()
    if c == "1":
        run_bat("5_INSTALL_DRIVER.bat")
    elif c == "2":
        run_bat("6_UNINSTALL_DRIVER.bat")


def main():
    actions = {
        "1": action_start,
        "2": action_stop,
        "3": lambda: run_py("vdd_tool.py", "status"),
        "4": lambda: run_py("portrait_setup.py", "setup-portrait"),
        "5": lambda: run_py("portrait_setup.py", "landscape"),
        "6": lambda: run_py("vdd_tool.py", "pick"),
        "7": lambda: run_py("vdd_tool.py", "move"),
        "8": lambda: run_py("vdd_tool.py", "windows"),
        "9": lambda: (T.clear_target(), print("\n  已清除，之后按 config.ini 的关键词自动匹配。")),
        "10": action_portrait_box,
        "11": lambda: run_py("vdd_tool.py", "modes", "--all"),
        "12": action_autostart,
        "13": lambda: run_bat("5_INSTALL_DRIVER.bat"),
        "14": lambda: run_bat("6_UNINSTALL_DRIVER.bat"),
        "15": action_start_admin,
    }
    print("\n  提示：本窗口可以随手关闭，不影响虚拟屏；保活宿主在后台运行。")
    while True:
        header()
        print(MENU)
        try:
            choice = input("  请输入编号 > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  已退出。")
            return 0
        if choice in ("0", "q", "Q", "exit"):
            print("\n  已退出。虚拟屏和后台宿主保持原状。")
            return 0
        fn = actions.get(choice)
        if not fn:
            print("  无效编号，请重新输入。")
            continue
        try:
            fn()
        except Exception as e:
            print("  [异常] %s: %s" % (type(e).__name__, e))
        pause()


if __name__ == "__main__":
    sys.exit(main())
