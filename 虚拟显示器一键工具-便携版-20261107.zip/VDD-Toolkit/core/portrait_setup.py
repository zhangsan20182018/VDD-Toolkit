# -*- coding: utf-8 -*-
"""
portrait_setup.py -- 竖屏（1080x1920）配置与横竖屏切换

Parsec VDD 0.45 的 91 个内置分辨率全是横屏，直接设置 1080x1920 会返回
DISP_CHANGE_BADMODE(-2)。Parsec 官方支持在注册表中添加最多 5 个自定义分辨率：

    HKLM\\SOFTWARE\\Parsec\\vdd\\0\\width   REG_DWORD 1080
    HKLM\\SOFTWARE\\Parsec\\vdd\\0\\height  REG_DWORD 1920
    HKLM\\SOFTWARE\\Parsec\\vdd\\0\\hz      REG_DWORD 60

写 HKLM 需要管理员。本脚本把「提权」限制在最小范围：
  setup-portrait (普通权限)
     -> 检测是否已就绪；未就绪则 ShellExecuteW runas 拉起 admin 子进程
     -> 等 admin 完成（写注册表 + 重启虚拟显卡使模式列表刷新）
     -> 回到普通权限：改 config.ini、重启保活宿主、验证结果
这样常驻宿主始终是普通权限，不会和高完整性进程混在一起。

命令：
  probe                 只读检测（退出码 0=已就绪 / 1=需要提权配置）
  admin                 内部使用：管理员子进程，写注册表 + 重启设备
  setup-portrait        一键切到竖屏（必要时自动弹一次 UAC）
  landscape             切回横屏 1920x1080（不需要管理员）
  verify                验证当前虚拟屏模式
"""
from __future__ import annotations

import ctypes
import json
import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import vdd_lib as L  # noqa: E402
import vdd_tool as T  # noqa: E402

ROOT = os.path.dirname(HERE)
CONFIG_PATH = os.path.join(ROOT, "config.ini")
LOG_DIR = os.path.join(ROOT, "logs")
DONE_FLAG = os.path.join(LOG_DIR, "admin_done.flag")
RESULT_PATH = os.path.join(LOG_DIR, "admin_result.json")
READY_FLAG = os.path.join(LOG_DIR, "mode_ready.flag")

REG_PATH = r"SOFTWARE\Parsec\vdd"
SLOT = "0"
PORTRAIT = (1080, 1920, 60)
LANDSCAPE = (1920, 1080, 60)

import winreg  # noqa: E402

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def say(msg):
    print(msg, flush=True)


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


# ---------------------------------------------------------------- 注册表
def read_custom_modes():
    """读 HKLM 自定义分辨率槽 0..4，返回 [(w,h,hz), ...]。"""
    out = []
    try:
        base = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, REG_PATH)
    except OSError:
        return out
    for i in range(5):
        try:
            k = winreg.OpenKey(base, str(i))
        except OSError:
            continue
        try:
            w = winreg.QueryValueEx(k, "width")[0]
            h = winreg.QueryValueEx(k, "height")[0]
            hz = winreg.QueryValueEx(k, "hz")[0]
            out.append((int(w), int(h), int(hz)))
        except OSError:
            pass
        finally:
            winreg.CloseKey(k)
    winreg.CloseKey(base)
    return out


def write_portrait_mode():
    base = winreg.CreateKeyEx(
        winreg.HKEY_LOCAL_MACHINE, REG_PATH, 0, winreg.KEY_ALL_ACCESS,
    )
    k = winreg.CreateKeyEx(base, SLOT, 0, winreg.KEY_ALL_ACCESS)
    w, h, hz = PORTRAIT
    winreg.SetValueEx(k, "width", 0, winreg.REG_DWORD, w)
    winreg.SetValueEx(k, "height", 0, winreg.REG_DWORD, h)
    winreg.SetValueEx(k, "hz", 0, winreg.REG_DWORD, hz)
    winreg.CloseKey(k)
    winreg.CloseKey(base)
    return (w, h, hz)


# ---------------------------------------------------------------- config.ini
def write_config_mode(width, height, hz=60):
    """就地改写分辨率三行，保留文件里的中文注释（不用 configparser 写回）。"""
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        text = f.read()
    for key, val in (("width", width), ("height", height), ("hz", hz)):
        pattern = r"(?m)^([ \t]*%s[ \t]*=[ \t]*)[^\r\n;]+" % key
        new, n = re.subn(pattern, lambda m: m.group(1) + str(val), text, count=1)
        if n == 0:
            raise RuntimeError("config.ini 里找不到 %s 配置项" % key)
        text = new
    with open(CONFIG_PATH, "w", encoding="utf-8", newline="") as f:
        f.write(text)


# ---------------------------------------------------------------- 设备重启
PS_RESTART = r"""
$ErrorActionPreference = 'Continue'
$dev = Get-PnpDevice -Class Display | Where-Object { $_.FriendlyName -like '*Parsec*' } | Select-Object -First 1
if (-not $dev) { Write-Output 'NO_DEVICE'; exit 2 }
$id = $dev.InstanceId
try { Disable-PnpDevice -InstanceId $id -Confirm:$false -ErrorAction Stop }
catch { Write-Output ('DISABLE_ERR:' + $_.Exception.Message) }
Start-Sleep -Seconds 2
$ok = $false
try { Enable-PnpDevice -InstanceId $id -Confirm:$false -ErrorAction Stop; $ok = $true }
catch { Write-Output ('ENABLE_ERR:' + $_.Exception.Message) }
if (-not $ok) {
  & pnputil.exe /enable-device $id | Out-Null
  Start-Sleep -Seconds 2
  $d2 = Get-PnpDevice -InstanceId $id -ErrorAction SilentlyContinue
  if ($d2 -and $d2.Status -eq 'OK') { $ok = $true }
}
Start-Sleep -Seconds 1
if ($ok) { Write-Output ('OK:' + $id) }
else { Write-Output ('FAIL:' + $id); exit 3 }
"""


def restart_adapter():
    """禁用再启用 Parsec 虚拟显卡，让驱动重新读取自定义分辨率。"""
    r = subprocess.run(
        ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", PS_RESTART],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=90,
    )
    out = r.stdout.decode("utf-8", errors="replace").strip()
    return r.returncode == 0 and "OK:" in out, out[-600:]


def probe_new_mode():
    """临时点亮一块虚拟屏，看驱动是否已经提供竖屏模式。"""
    v = L.VDD()
    try:
        v.open()
    except Exception as e:
        return False, "驱动设备打不开: %s" % e
    idx = None
    stop = [False]

    def ping():
        while not stop[0]:
            try:
                v.update()
            except Exception:
                pass
            time.sleep(0.06)

    import threading
    th = threading.Thread(target=ping, daemon=True)
    th.start()
    try:
        if not L.find_vdd_display_name():
            idx = v.add()
        if not T.wait_for_vdd(timeout=15.0):
            return False, "15 秒内未检测到虚拟屏"
        # 设备刚重启时模式表可能还是旧的 EDID；多等一会儿，并允许重新枚举。
        time.sleep(2.5)
        modes = L.list_modes()
        ok = L.has_mode(PORTRAIT[0], PORTRAIT[1], PORTRAIT[2])
        return ok, "驱动共上报 %d 种模式，1080x1920@60 %s" % (
            len(modes), "已可用" if ok else "仍不可用（通常需要重启电脑）",
        )
    finally:
        stop[0] = True
        time.sleep(0.15)
        try:
            if idx is not None and idx >= 0:
                v.remove(idx)
            else:
                for i in range(3):
                    v.remove(i)
                    time.sleep(0.1)
        except Exception:
            pass
        v.close()


# ---------------------------------------------------------------- admin 子进程
def cmd_admin():
    if not is_admin():
        say("[错误] 本步骤必须以管理员身份运行。")
        _write_result({"ok": False, "msg": "未获得管理员权限（UAC 被取消）"})
        return 1
    result = {"ok": False, "steps": []}
    try:
        w, h, hz = write_portrait_mode()
        result["steps"].append("已写入自定义分辨率 %dx%d@%dHz 到 %s\\%s" % (
            w, h, hz, REG_PATH, SLOT,
        ))
    except Exception as e:
        result["msg"] = "写注册表失败: %s" % e
        _write_result(result)
        say("[失败] " + result["msg"])
        return 1
    try:
        ok, detail = restart_adapter()
        result["steps"].append("重启虚拟显卡: %s" % ("成功" if ok else "失败 -> " + detail))
    except Exception as e:
        ok = False
        result["steps"].append("重启虚拟显卡异常: %s" % e)
    if ok:
        try:
            mode_ok, detail = probe_new_mode()
            result["steps"].append("模式检测: " + detail)
            result["mode_ready"] = mode_ok
        except Exception as e:
            result["steps"].append("模式检测异常: %s" % e)
            result["mode_ready"] = False
    result["ok"] = True
    result["msg"] = "驱动配置完成" if ok else "注册表已写入，但重启设备失败，请重启一次电脑"
    _write_result(result)
    for s in result["steps"]:
        say("  " + s)
    say("[完成] " + result["msg"])
    return 0


def _write_result(data):
    os.makedirs(LOG_DIR, exist_ok=True)
    with open(RESULT_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    with open(DONE_FLAG, "w", encoding="utf-8") as f:
        f.write("done")


def elevate_admin(timeout=None):
    """弹一次 UAC，等待管理员子进程完成，返回 (成功?, 结果字典)。"""
    os.makedirs(LOG_DIR, exist_ok=True)
    for p in (DONE_FLAG, RESULT_PATH, READY_FLAG):
        try:
            if os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass
    script = os.path.join(HERE, "portrait_setup.py")
    params = '"%s" admin' % script
    rc = ctypes.windll.shell32.ShellExecuteW(
        None, "runas", sys.executable, params, None, 1,
    )
    if rc <= 32:
        return False, {"msg": "无法请求管理员权限 (ShellExecute=%s)，UAC 可能被取消" % rc}
    wait = float(timeout or os.environ.get("VDD_UAC_WAIT", "180"))
    say(" 已弹出 UAC 授权窗口，请在弹窗里点「是」（最多等 %d 秒）……" % int(wait))
    deadline = time.time() + wait
    while time.time() < deadline:
        if os.path.isfile(DONE_FLAG):
            time.sleep(0.4)
            try:
                with open(RESULT_PATH, "r", encoding="utf-8") as f:
                    return True, json.load(f)
            except Exception as e:
                return False, {"msg": "读取管理员步骤结果失败: %s" % e}
        time.sleep(0.5)
    return False, {"msg": "等待管理员步骤超时（3 分钟）"}


# ---------------------------------------------------------------- 宿主重启
def unplug_leftover():
    """没有宿主时，显式拔出系统残留的虚拟屏。"""
    try:
        subprocess.run(
            [sys.executable, os.path.join(HERE, "vdd_tool.py"), "remove"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=25,
        )
    except Exception:
        pass


def stop_host():
    """写 STOP.flag 让宿主自己退出并拔出虚拟屏。"""
    os.makedirs(LOG_DIR, exist_ok=True)
    if not L.singleton_exists():
        # 宿主已退出但系统可能仍残留这块屏，直接拔掉，不必白等 10 秒。
        unplug_leftover()
        return False
    flag = T.STOP_FLAG
    with open(flag, "w", encoding="utf-8") as f:
        f.write("stop\n")
    deadline = time.time() + 10
    while time.time() < deadline:
        if not os.path.isfile(flag):
            time.sleep(0.8)
            return True
        time.sleep(0.3)
    try:
        os.remove(flag)
    except Exception:
        pass
    unplug_leftover()
    return False


def start_host():
    """启动常驻宿主。

    优先经桌面 Shell(explorer.exe) 代理：由 explorer 派生的进程脱离当前会话的
    Job Object，实测跨会话不会被清理；从受限会话（工具 / 计划任务）启动尤其关键。
    """
    launcher = os.path.join(HERE, "launch_host.bat")
    if os.path.isfile(launcher):
        try:
            subprocess.Popen(
                ["explorer.exe", launcher], close_fds=True,
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return None
        except Exception:
            pass
    pyw = os.path.join(ROOT, "runtime", "pythonw.exe")
    if not os.path.isfile(pyw):
        pyw = os.path.join(ROOT, "runtime", "python.exe")
    tool = os.path.join(HERE, "vdd_tool.py")
    DETACHED_PROCESS = 0x00000008
    CREATE_NEW_PROCESS_GROUP = 0x00000200
    CREATE_BREAKAWAY_FROM_JOB = 0x01000000
    base_flags = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    kw = dict(
        cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL, close_fds=True,
    )
    try:
        # 从受限会话（工具 / 计划任务 / 服务）启动时，脱离父进程 Job Object，
        # 否则会话结束会把宿主一起清理掉，导致虚拟屏残留但画面冻结。
        p = subprocess.Popen(
            [pyw, tool, "host"],
            creationflags=base_flags | CREATE_BREAKAWAY_FROM_JOB, **kw,
        )
    except OSError:
        p = subprocess.Popen(
            [pyw, tool, "host"], creationflags=base_flags, **kw,
        )
    return p.pid


def apply_mode(width, height, hz=60, restart_host=True):
    write_config_mode(width, height, hz)
    say(" 已更新 config.ini -> %dx%d@%dHz" % (width, height, hz))
    if restart_host:
        say(" 正在重启保活宿主……")
        stop_host()
        time.sleep(1.0)
        pid = start_host()
        say(" 保活宿主已启动 (%s)" % ("PID %s" % pid if pid else "桌面 Shell 后台"))
        for _ in range(30):
            time.sleep(0.5)
            if L.find_vdd_display_name():
                break
        time.sleep(1.5)
    return verify_mode(width, height)


def verify_mode(width, height):
    name = L.find_vdd_display_name()
    if not name:
        say(" [结果] 虚拟屏未点亮，请双击 1_START.bat 后再用 0_STATUS.bat 复查。")
        return False
    dm = L.current_mode(name)
    rect = L.vdd_screen_rect()
    if dm:
        ok = dm.dmPelsWidth == width and dm.dmPelsHeight == height
        say(" [结果] %s 当前 %dx%d @ %dHz，坐标 %s" % (
            name, dm.dmPelsWidth, dm.dmPelsHeight, dm.dmDisplayFrequency,
            "(%d,%d) %dx%d" % rect if rect else "?",
        ))
        return ok
    say(" [结果] 无法读取当前显示模式。")
    return False


# ---------------------------------------------------------------- 命令入口
def registry_has_portrait():
    return PORTRAIT in read_custom_modes()


def cmd_probe():
    reg = registry_has_portrait()
    lit = L.find_vdd_display_name() is not None
    mode_ok = L.has_mode(*PORTRAIT) if lit else None
    say("注册表自定义模式 : %s" % ("已有 1080x1920@60" if reg else "未配置"))
    say("虚拟屏当前状态   : %s" % ("已点亮" if lit else "未点亮"))
    say("驱动竖屏模式     : %s" % (
        "已可用" if mode_ok else "不可用" if mode_ok is False else "无法检测（未点亮）",
    ))
    ready = bool(mode_ok) or (not lit and reg)
    if ready:
        try:
            with open(READY_FLAG, "w", encoding="utf-8") as f:
                f.write("ready\n")
        except Exception:
            pass
    return 0 if ready else 1


def cmd_setup_portrait():
    say("=" * 62)
    say(" 一键切换虚拟显示器为竖屏 1080x1920@60")
    say("=" * 62)
    lit = L.find_vdd_display_name() is not None
    mode_ready = L.has_mode(*PORTRAIT) if lit else False
    # 注册表已配置但虚拟屏没点亮时，不再重复弹 UAC：重新启动宿主会重新
    # 添加虚拟屏并触发驱动重建分辨率表，那本身就是一次刷新。
    already_configured = registry_has_portrait()
    need_admin = not (mode_ready or (not lit and already_configured))

    if need_admin:
        say(" 驱动尚未提供 1080x1920 模式，需要添加自定义分辨率并刷新驱动。")
        say(" 这一步要写 HKLM 注册表，Windows 会弹一次 UAC 授权。")
        # 设备重启会让宿主手里的驱动句柄失效，先让它干净退出。
        if L.singleton_exists():
            say(" 正在暂停保活宿主……")
            stop_host()
        ok, res = elevate_admin()
        if not ok or not res.get("ok"):
            say(" [失败] " + res.get("msg", "未知原因"))
            say(" 可改用免管理员方案：把 config.ini 的 portrait_box 设为 1。")
            return 1
        for s in res.get("steps", []):
            say("   - " + s)
        # 驱动刚重启时模式表可能还没刷新完，所以不把这一步的探测结果当作
        # 最终判据：下面重启宿主会重新添加虚拟屏，那时再做真实设置与回读。
        say(" 驱动配置完成，正在重新点亮虚拟屏以刷新分辨率表……")
    else:
        say(" 竖屏模式已就绪，无需管理员权限。")

    say(" 正在切换到竖屏……")
    ok = apply_mode(*PORTRAIT)
    if ok:
        say(" [成功] 虚拟显示器现在是 1080x1920 竖屏。")
        say(" 采集端请用「显示器采集」选 Parsec Virtual Display Adapter，天然就是 9:16。")
    else:
        # 保持配置与实际状态一致，避免宿主每次启动都去试一个不存在的模式。
        write_config_mode(*LANDSCAPE)
        say(" [未完成] 分辨率没切过去，config.ini 已还原为横屏。")
        say(" 请重启一次电脑，再运行本脚本（注册表已写好，这次不会再弹 UAC）。")
        say(" 临时替代：config.ini 设 portrait_box = 1（免权限的 9:16 居中布局）。")
    return 0 if ok else 1


def cmd_landscape():
    say("=" * 62)
    say(" 切回横屏 1920x1080@60（不需要管理员）")
    say("=" * 62)
    ok = apply_mode(*LANDSCAPE)
    say(" [成功] 已切回横屏。" if ok else " [未完成] 请用 0_STATUS.bat 复查。")
    return 0 if ok else 1


def cmd_verify():
    cfg = T.load_config()
    return 0 if verify_mode(cfg["width"], cfg["height"]) else 1


def main():
    action = (sys.argv[1] if len(sys.argv) > 1 else "probe").lower()
    table = {
        "probe": cmd_probe,
        "admin": cmd_admin,
        "setup-portrait": cmd_setup_portrait,
        "landscape": cmd_landscape,
        "verify": cmd_verify,
    }
    if action not in table:
        say("未知命令: %s" % action)
        return 2
    try:
        return table[action]()
    except Exception as e:
        say("[异常] %s: %s" % (type(e).__name__, e))
        if action == "admin":
            _write_result({"ok": False, "msg": str(e)})
        return 2


if __name__ == "__main__":
    sys.exit(main())
