# -*- coding: utf-8 -*-
"""
setup_autostart.py -- 管理「登录时自动启动虚拟显示器保活宿主」

用 HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run 注册表项。
注册表值是 Unicode 原生字符串，不依赖 VBS、8.3 短路径或系统 ANSI 编码，
因此文件夹放在任何中文 / 非中文路径下都能正确工作，也不需要管理员权限。

  install -> 写入 VDD-Host 值，登录后用 pythonw.exe 静默启动（无黑窗口）
  remove  -> 删除该值（并清理旧版本可能残留的 VBS 启动器）
"""
from __future__ import annotations

import os
import sys
import winreg

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
VALUE_NAME = "VDD-Host"
LEGACY_VBS = os.path.join(
    os.environ.get("APPDATA", ""),
    r"Microsoft\Windows\Start Menu\Programs\Startup\VDD-Host.vbs",
)


def cleanup_legacy():
    """清掉早期版本可能写入的 VBS 启动器。"""
    try:
        if os.path.isfile(LEGACY_VBS):
            os.remove(LEGACY_VBS)
            print("已清理旧版 VBS 启动器。")
    except Exception:
        pass


def main():
    action = (sys.argv[1] if len(sys.argv) > 1 else "install").lower()
    cleanup_legacy()

    if action == "remove":
        try:
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE,
            ) as k:
                winreg.DeleteValue(k, VALUE_NAME)
            print("已取消开机自启。")
        except FileNotFoundError:
            print("本来就没有设置开机自启。")
        return 0

    pyw = os.path.join(ROOT, "runtime", "pythonw.exe")
    if not os.path.isfile(pyw):
        pyw = os.path.join(ROOT, "runtime", "python.exe")
    tool = os.path.join(ROOT, "core", "vdd_tool.py")
    if not os.path.isfile(pyw) or not os.path.isfile(tool):
        print("缺少 runtime/pythonw.exe 或 core/vdd_tool.py，无法设置自启。")
        return 1

    cmd = '"%s" "%s" host' % (pyw, tool)
    with winreg.CreateKeyEx(
        winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE,
    ) as k:
        winreg.SetValueEx(k, VALUE_NAME, 0, winreg.REG_SZ, cmd)
    print("已设置开机自启（登录后静默启动，无窗口）：")
    print("  " + cmd)
    print("取消方式：运行 8_REMOVE_AUTOSTART.bat")
    return 0


if __name__ == "__main__":
    sys.exit(main())
