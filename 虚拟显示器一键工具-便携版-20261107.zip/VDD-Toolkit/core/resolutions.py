# -*- coding: utf-8 -*-
"""通用分辨率管理：预设档位、自定义分辨率、一键切换。

Parsec VDD 0.45 内置 91 个模式全是横屏（最高 4096x2160）。竖屏必须走
Parsec 官方自定义分辨率（HKLM\\SOFTWARE\\Parsec\\vdd\\<0..4>，最多 5 个）。

本模块把「内置模式」和「自定义模式」统一成一个 switch(w,h,hz)：
  - 内置模式：直接改 config.ini + 重启宿主，零 UAC。
  - 自定义模式：注册表里没有就弹一次 UAC 写入并重启虚拟显卡，
    之后所有切换都不再需要管理员。

命令行：
  python resolutions.py list                 列出档位与可用性
  python resolutions.py switch 2560 1440 60 切到指定分辨率
  python resolutions.py admin 1440 2560 60  内部使用（管理员子进程）
"""
from __future__ import annotations

import ctypes
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import vdd_lib as L          # noqa: E402
import vdd_tool as T         # noqa: E402
import portrait_setup as P   # noqa: E402

ROOT = os.path.dirname(HERE)
LOG_DIR = os.path.join(ROOT, "logs")
RESULT = os.path.join(LOG_DIR, "res_admin_result.json")
DONE = os.path.join(LOG_DIR, "res_admin_done.flag")

# 给新手的档位。custom=True 表示驱动不内置，需要注册表自定义（一次 UAC）。
PRESETS = [
    {"key": "1080p_p", "label": "1080P 竖屏", "sub": "1080×1920 · 9:16",
     "w": 1080, "h": 1920, "hz": 60, "custom": True, "rec": True},
    {"key": "2k_p", "label": "2K 竖屏", "sub": "1440×2560 · 9:16",
     "w": 1440, "h": 2560, "hz": 60, "custom": True, "rec": False},
    {"key": "1080p", "label": "1080P 横屏", "sub": "1920×1080 · 16:9",
     "w": 1920, "h": 1080, "hz": 60, "custom": False, "rec": False},
    {"key": "2k", "label": "2K 横屏", "sub": "2560×1440 · 16:9",
     "w": 2560, "h": 1440, "hz": 60, "custom": False, "rec": True},
]

import winreg  # noqa: E402

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def say(msg):
    print(msg, flush=True)


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


# ------------------------------------------------------------------ 注册表
def read_custom():
    """[(slot, w, h, hz), ...] 读 5 个自定义槽。"""
    out = []
    try:
        base = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, P.REG_PATH)
    except OSError:
        return out
    for i in range(5):
        try:
            k = winreg.OpenKey(base, str(i))
        except OSError:
            continue
        try:
            out.append((i,
                        int(winreg.QueryValueEx(k, "width")[0]),
                        int(winreg.QueryValueEx(k, "height")[0]),
                        int(winreg.QueryValueEx(k, "hz")[0])))
        except OSError:
            pass
        finally:
            winreg.CloseKey(k)
    winreg.CloseKey(base)
    return out


def write_custom(slot, w, h, hz):
    base = winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, P.REG_PATH, 0,
                              winreg.KEY_ALL_ACCESS)
    k = winreg.CreateKeyEx(base, str(slot), 0, winreg.KEY_ALL_ACCESS)
    winreg.SetValueEx(k, "width", 0, winreg.REG_DWORD, int(w))
    winreg.SetValueEx(k, "height", 0, winreg.REG_DWORD, int(h))
    winreg.SetValueEx(k, "hz", 0, winreg.REG_DWORD, int(hz))
    winreg.CloseKey(k)
    winreg.CloseKey(base)


def delete_custom(slot):
    try:
        base = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, P.REG_PATH, 0,
                              winreg.KEY_ALL_ACCESS)
        winreg.DeleteKey(base, str(slot))
        winreg.CloseKey(base)
        return True
    except OSError:
        return False


def custom_slot(w, h, hz):
    for slot, cw, ch, chz in read_custom():
        if (cw, ch, chz) == (int(w), int(h), int(hz)):
            return slot
    return None


def free_slot():
    used = {s for s, _, _, _ in read_custom()}
    for i in range(5):
        if i not in used:
            return i
    return None


# ------------------------------------------------------------------ 模式探测
def cds_test(w, h, hz, name=None):
    """只测试不改设置。返回 0=支持 / -2=不支持 / None=虚拟屏未点亮。"""
    name = name or L.find_vdd_display_name()
    if not name:
        return None
    dm = L.current_mode(name)
    if dm is None:
        return None
    dm.dmPelsWidth = int(w)
    dm.dmPelsHeight = int(h)
    dm.dmDisplayFrequency = int(hz)
    dm.dmFields = L.DM_PELSWIDTH | L.DM_PELSHEIGHT | L.DM_DISPLAYFREQUENCY
    return int(L._u32.ChangeDisplaySettingsExW(
        name, ctypes.byref(dm), None, L.CDS_TEST, None,
    ))


def probe_mode(w, h, hz, timeout=25.0, keep_alive=True):
    """点亮一块临时虚拟屏，反复 CDS_TEST 直到驱动给出结论。

    刚重启显卡时 EDID 模式表会滞后几秒，所以不能只测一次。
    """
    v = L.VDD()
    try:
        v.open()
    except Exception as e:
        return False, "驱动设备打不开: %s" % e
    idx = None
    stop = [False]

    def ping():
        while not stop[0]:
            try:
                v.update()
            except Exception:
                pass
            time.sleep(0.06)

    import threading
    threading.Thread(target=ping, daemon=True).start()
    try:
        if not L.find_vdd_display_name():
            idx = v.add()
        if not T.wait_for_vdd(timeout=15.0):
            return False, "15 秒内未检测到虚拟屏"
        deadline = time.time() + timeout
        last = None
        while time.time() < deadline:
            last = cds_test(w, h, hz)
            if last == 0:
                return True, "%dx%d@%dHz 已可用（CDS_TEST=0）" % (w, h, hz)
            time.sleep(1.0)
        return False, "%dx%d@%dHz 不被驱动接受（CDS_TEST=%s）" % (w, h, hz, last)
    finally:
        stop[0] = True
        time.sleep(0.15)
        if not keep_alive:
            try:
                if idx is not None and idx >= 0:
                    v.remove(idx)
                else:
                    for i in range(3):
                        v.remove(i)
                        time.sleep(0.1)
            except Exception:
                pass
        v.close()


# ------------------------------------------------------------------ admin 子进程
def _write_result(data):
    os.makedirs(LOG_DIR, exist_ok=True)
    with open(RESULT, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    with open(DONE, "w", encoding="utf-8") as f:
        f.write("done")


def cmd_admin(w, h, hz):
    """管理员：写自定义分辨率 -> 重启虚拟显卡 -> 验证驱动是否接受。"""
    if not is_admin():
        _write_result({"ok": False, "msg": "未获得管理员权限（UAC 被取消）"})
        return 1
    res = {"ok": False, "steps": [], "accepted": False}
    slot = custom_slot(w, h, hz)
    if slot is None:
        slot = free_slot()
        if slot is None:
            _write_result({"ok": False, "msg": "5 个自定义分辨率槽已满"})
            return 1
    try:
        write_custom(slot, w, h, hz)
        res["steps"].append("已写入注册表槽 %d: %dx%d@%dHz" % (slot, w, h, hz))
        res["slot"] = slot
    except Exception as e:
        _write_result({"ok": False, "msg": "写注册表失败: %s" % e})
        return 1
    try:
        ok, detail = P.restart_adapter()
        res["steps"].append("重启虚拟显卡: %s" % ("成功" if ok else "失败 " + detail))
    except Exception as e:
        ok = False
        res["steps"].append("重启虚拟显卡异常: %s" % e)
    accepted = False
    if ok:
        try:
            accepted, detail = probe_mode(w, h, hz, timeout=25.0, keep_alive=False)
            res["steps"].append("驱动验证: " + detail)
        except Exception as e:
            res["steps"].append("驱动验证异常: %s" % e)
    res["accepted"] = accepted
    if not accepted:
        # 驱动不认这个尺寸：删掉刚写的槽，避免留下无效配置。
        delete_custom(slot)
        res["steps"].append("驱动不接受该尺寸，已回滚注册表槽 %d" % slot)
        res["msg"] = "驱动不支持 %dx%d，可改用其它档位" % (w, h)
        _write_result(res)
        return 1
    res["ok"] = True
    res["msg"] = "自定义分辨率 %dx%d@%dHz 已生效" % (w, h, hz)
    _write_result(res)
    for s in res["steps"]:
        say("  " + s)
    say("[完成] " + res["msg"])
    return 0


def elevate_admin(w, h, hz, timeout=None):
    """弹一次 UAC，返回 (ok, result)。"""
    os.makedirs(LOG_DIR, exist_ok=True)
    for p in (DONE, RESULT):
        try:
            if os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass
    script = os.path.abspath(__file__)
    params = '"%s" admin %d %d %d' % (script, int(w), int(h), int(hz))
    rc = ctypes.windll.shell32.ShellExecuteW(
        None, "runas", sys.executable, params, ROOT, 0,
    )
    if rc <= 32:
        return False, {"msg": "无法请求管理员权限（UAC 可能被取消，rc=%s）" % rc}
    wait = float(timeout or os.environ.get("VDD_UAC_WAIT", "120"))
    deadline = time.time() + wait
    while time.time() < deadline:
        if os.path.isfile(DONE):
            time.sleep(0.4)
            try:
                with open(RESULT, "r", encoding="utf-8") as f:
                    return True, json.load(f)
            except Exception as e:
                return False, {"msg": "读取管理员结果失败: %s" % e}
        time.sleep(0.5)
    return False, {"msg": "等待 UAC 授权超时"}


# ------------------------------------------------------------------ 状态 / 切换
def presets_status():
    """给 UI 用：每个档位是否可用、是否需要 UAC。"""
    name = L.find_vdd_display_name()
    customs = read_custom()
    out = []
    for p in PRESETS:
        w, h, hz = p["w"], p["h"], p["hz"]
        test = cds_test(w, h, hz, name) if name else None
        in_reg = custom_slot(w, h, hz) is not None
        out.append(dict(p,
                        available=(test == 0),
                        in_registry=in_reg,
                        need_uac=(test != 0 and not in_reg and p["custom"]),
                        cds_test=test))
    return out


def ensure_display_lit(emit=None):
    """确保虚拟屏已点亮（宿主不在时临时拉起）。"""
    emit = emit or (lambda s: None)
    if L.find_vdd_display_name():
        return True
    if not L.singleton_exists():
        emit(" 正在启动保活宿主……")
        P.start_host()
    return bool(T.wait_for_vdd(timeout=20.0))


def switch(w, h, hz=60, emit=None):
    """切换到任意分辨率，必要时自动弹一次 UAC。返回 (ok, [日志])。"""
    emit = emit or (lambda s: None)
    w, h, hz = int(w), int(h), int(hz)
    logs = []

    def note(s):
        logs.append(s)
        emit(s)
        say(s)

    cfg = T.load_config()
    old = (cfg["width"], cfg["height"], cfg["hz"])
    note("目标分辨率：%dx%d@%dHz" % (w, h, hz))

    # 1) 先点亮虚拟屏，才能用 CDS_TEST 判断驱动是否支持
    if not ensure_display_lit(emit=note):
        note(" [失败] 虚拟屏无法点亮，请检查驱动是否已安装。")
        return False, logs

    host_stopped = False
    test = cds_test(w, h, hz)
    if test == 0:
        note(" 驱动已支持该模式，无需管理员权限。")
    else:
        in_reg = custom_slot(w, h, hz) is not None
        if not in_reg:
            note(" 该模式需要添加到驱动（最多 5 个自定义分辨率）。")
            note(" 正在请求一次 Windows 授权（UAC），请在弹窗里点「是」……")
            # 重启虚拟显卡会让宿主手里的驱动句柄失效，只能先停掉。
            if L.singleton_exists():
                P.stop_host()
                host_stopped = True
                time.sleep(0.8)
            ok, res = elevate_admin(w, h, hz)
            for s in res.get("steps", []):
                note("   - " + s)
            if not ok or not res.get("ok"):
                note(" [失败] " + res.get("msg", "未知原因"))
                P.start_host()
                return False, logs
        else:
            note(" 自定义模式已在注册表，尝试原地刷新。")
        if host_stopped:
            note(" 设备已重启，正在重新点亮虚拟屏……")
            P.start_host()
            T.wait_for_vdd(timeout=25.0)
            time.sleep(1.2)

    # 2) 改 config.ini + 原地设置。
    #    关键：不要为了切分辨率重启保活宿主。宿主的完整性级别（管理员）
    #    是从启动它的进程继承的，一重启就掉回普通权限，抖音预览窗口会
    #    立刻变成「投不动」。只有原地设置失败时才回退到重启宿主。
    note(" 正在应用分辨率……")
    P.write_config_mode(w, h, hz)
    ok = False
    if L.find_vdd_display_name():
        code, msg = L.set_display_mode(w, h, hz)
        note(" 设置返回：%s (code=%d)" % (msg, code))
        time.sleep(1.0)
        ok = P.verify_mode(w, h)
    if not ok:
        note(" 原地设置未生效，回退为重启宿主触发驱动刷新……")
        ok = P.apply_mode(w, h, hz)
        if ok:
            note(" 注意：宿主重启后可能是普通权限，必要时点控制面板的「一键开启」重新授权。")
    if ok:
        try:
            T.do_move(T.load_config(), verbose=False)
            note(" 已按新分辨率重新投送画面窗口")
        except Exception:
            pass
        note(" [成功] 虚拟显示器现在是 %dx%d@%dHz。" % (w, h, hz))
    else:
        note(" [失败] 切换未生效，已还原原分辨率。")
        P.write_config_mode(*old)
    return ok, logs


# ------------------------------------------------------------------ CLI
def cmd_list():
    say("=" * 68)
    say(" 可用分辨率档位")
    say("=" * 68)
    for s in presets_status():
        say("  %-14s %-22s 驱动=%-6s 注册表=%-4s %s" % (
            s["label"], s["sub"],
            "支持" if s["available"] else "不支持",
            "已配置" if s["in_registry"] else "-",
            "（首次切换需一次 UAC）" if s["need_uac"] else "",
        ))
    say("-" * 68)
    say(" 已配置的自定义分辨率：")
    for slot, w, h, hz in read_custom():
        say("   槽 %d -> %dx%d@%dHz" % (slot, w, h, hz))
    return 0


def main():
    action = (sys.argv[1] if len(sys.argv) > 1 else "list").lower()
    if action == "list":
        return cmd_list()
    if action == "admin":
        if len(sys.argv) < 5:
            say("用法: resolutions.py admin <w> <h> <hz>")
            return 2
        return cmd_admin(int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]))
    if action == "switch":
        if len(sys.argv) < 4:
            say("用法: resolutions.py switch <w> <h> [hz]")
            return 2
        hz = int(sys.argv[4]) if len(sys.argv) > 4 else 60
        ok, _ = switch(int(sys.argv[2]), int(sys.argv[3]), hz)
        return 0 if ok else 1
    if action == "probe":
        if len(sys.argv) < 4:
            say("用法: resolutions.py probe <w> <h> [hz]")
            return 2
        hz = int(sys.argv[4]) if len(sys.argv) > 4 else 60
        ok, msg = probe_mode(int(sys.argv[2]), int(sys.argv[3]), hz,
                             keep_alive=False)
        say(msg)
        return 0 if ok else 1
    say("未知命令: " + action)
    return 2


if __name__ == "__main__":
    sys.exit(main())
