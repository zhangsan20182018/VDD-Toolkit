@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo  ============================================================
echo   Start virtual display host WITH ADMINISTRATOR rights.
echo.
echo   Douyin Live Companion runs as administrator. Windows blocks
echo   normal processes from moving its windows (UIPI / access denied).
echo   So auto-move, hotkeys and window-pick need an elevated host.
echo.
echo   A UAC prompt will appear. Please click "Yes".
echo  ============================================================
echo.
"runtime\python.exe" "core\admin_host.py"
echo.
pause
