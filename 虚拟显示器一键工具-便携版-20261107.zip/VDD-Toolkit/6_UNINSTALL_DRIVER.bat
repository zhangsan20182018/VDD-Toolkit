@echo off
chcp 65001 >nul
cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 goto noadmin

echo.
echo  This REMOVES the Parsec virtual display driver from this PC.
echo  Run 8_REMOVE_AUTOSTART.bat first if you enabled auto-start.
echo.
echo  Press any key to continue, or close this window to cancel.
pause >nul

"%~dp0driver\nefconw.exe" --remove-device-node --hardware-id Root\Parsec\VDA --class-guid "4D36E968-E325-11CE-BFC1-08002BE10318"
"%~dp0driver\nefconw.exe" --uninstall-driver --inf-path "%~dp0driver\mm.inf"

echo.
echo  Driver removed. REBOOT to finish.
echo.
pause
exit /b 0

:noadmin
echo.
echo  [!] Administrator rights required.
echo  [!] Trying to elevate automatically... (accept the UAC prompt)
echo.
powershell -NoProfile -Command "Start-Process -FilePath '%~s0' -Verb RunAs" 2>nul
if errorlevel 1 (
  echo  [!] Auto-elevation failed.
  echo  [!] Please RIGHT-CLICK this .bat and pick "Run as administrator".
  pause
)
exit /b 0
