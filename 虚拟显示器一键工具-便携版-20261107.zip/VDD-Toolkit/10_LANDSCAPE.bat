@echo off
chcp 65001 >nul
title VDD Toolkit - Landscape 1920x1080
cd /d "%~dp0"
set "PYEXE=%~dp0runtime\python.exe"
if not exist "%PYEXE%" set "PYEXE=python"
"%PYEXE%" "%~dp0core\portrait_setup.py" landscape
echo.
pause
