@echo off
chcp 65001 >nul
title VDD Toolkit - Control Panel
cd /d "%~dp0"
set "PYEXE=%~dp0runtime\python.exe"
if not exist "%PYEXE%" set "PYEXE=python"
"%PYEXE%" "%~dp0core\menu.py"
