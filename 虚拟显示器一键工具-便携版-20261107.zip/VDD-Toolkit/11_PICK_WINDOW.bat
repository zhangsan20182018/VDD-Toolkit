@echo off
chcp 65001 >nul
title VDD Toolkit - Pick Target Window
cd /d "%~dp0"
set "PYEXE=%~dp0runtime\python.exe"
if not exist "%PYEXE%" set "PYEXE=python"
"%PYEXE%" "%~dp0core\vdd_tool.py" pick
echo.
pause
