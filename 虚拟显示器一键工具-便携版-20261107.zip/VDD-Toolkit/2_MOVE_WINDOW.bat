@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PYEXE=%~dp0runtime\python.exe"
if exist "%PYEXE%" goto run
set "PYEXE=python"
:run
echo.
"%PYEXE%" "%~dp0core\vdd_tool.py" move
echo.
echo  If nothing moved: run 3_LIST_WINDOWS.bat, then edit title_keywords
echo  in config.ini to match the real window title.
echo.
pause
