@echo off
chcp 65001 >nul
cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 goto noadmin

echo.
echo  ============================================================
echo   Installing Parsec Virtual Display Driver (v0.45)
echo   Only needed ONCE on a new computer.
echo  ============================================================
echo.
echo  Press any key to continue, or close this window to cancel.
pause >nul

echo  [1/3] remove old device node (if any)
"%~dp0driver\nefconw.exe" --remove-device-node --hardware-id Root\Parsec\VDA --class-guid "4D36E968-E325-11CE-BFC1-08002BE10318"
echo  [2/3] create device node
"%~dp0driver\nefconw.exe" --create-device-node --class-name Display --class-guid "4D36E968-E325-11CE-BFC1-08002BE10318" --hardware-id Root\Parsec\VDA
echo  [3/3] install signed driver
"%~dp0driver\nefconw.exe" --install-driver --inf-path "%~dp0driver\mm.inf"

echo.
echo  Done. REBOOT the computer, then run 1_START.bat.
echo  Verify with 0_STATUS.bat (should show "driver OK").
echo.
pause
exit /b 0

:noadmin
echo.
echo  [!] Administrator rights required for driver installation.
echo  [!] Trying to elevate automatically... (accept the UAC prompt)
echo.
powershell -NoProfile -Command "Start-Process -FilePath '%~s0' -Verb RunAs" 2>nul
if errorlevel 1 (
  echo  [!] Auto-elevation failed.
  echo  [!] Please RIGHT-CLICK this .bat and pick "Run as administrator".
  pause
)
exit /b 0
