@echo off
chcp 65001 >nul
title VDD Toolkit - Portrait 1080x1920
cd /d "%~dp0"
set "PYEXE=%~dp0runtime\python.exe"
if not exist "%PYEXE%" set "PYEXE=python"
"%PYEXE%" "%~dp0core\portrait_setup.py" setup-portrait
echo.
pause
