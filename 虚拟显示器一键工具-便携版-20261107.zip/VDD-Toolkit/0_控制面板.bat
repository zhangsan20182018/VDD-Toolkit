@echo off
chcp 65001 >nul
cd /d "%~dp0"
title VDD Control Panel

if not exist "runtime\pythonw.exe" goto missing
if not exist "core\webui.py" goto missing

echo.
echo  ============================================================
echo   Starting the visual control panel...
echo   A window will open automatically in a moment.
echo  ============================================================
echo.

start "" "runtime\pythonw.exe" "core\webui.py" --auto
ping -n 6 127.0.0.1 >nul

"runtime\python.exe" -c "import socket,sys; s=socket.socket(); s.settimeout(1); sys.exit(0 if s.connect_ex(('127.0.0.1',17876))==0 else 1)" >nul 2>&1
if errorlevel 1 goto failed

echo   [OK] Control panel is running.
echo   Tip: right-click this file - Send to - Desktop (create shortcut).
echo.
ping -n 3 127.0.0.1 >nul
exit /b 0

:failed
echo   [ERROR] The panel did not start. See logs\webui.log
echo   You can still use 0_MENU.bat as a fallback.
echo   (This window closes automatically in 10 seconds.)
echo.
ping -n 11 127.0.0.1 >nul
exit /b 1

:missing
echo   [ERROR] Missing runtime\pythonw.exe or core\webui.py
echo   Please copy the WHOLE VDD-Toolkit folder, not just this file.
echo.
pause
exit /b 1
