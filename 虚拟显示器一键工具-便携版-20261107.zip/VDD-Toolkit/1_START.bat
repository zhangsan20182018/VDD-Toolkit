@echo off
chcp 65001 >nul
title VDD Host - KEEP THIS WINDOW OPEN
cd /d "%~dp0"

set "PYEXE=%~dp0runtime\python.exe"
if exist "%PYEXE%" goto checkdriver
set "PYEXE=python"
where python >nul 2>&1
if errorlevel 1 goto nopython

:checkdriver
"%PYEXE%" "%~dp0core\vdd_tool.py" check >nul 2>&1
if errorlevel 1 goto nodriver

echo.
echo  ============================================================
echo   Starting virtual display host.
echo   KEEP THIS WINDOW OPEN while you are streaming.
echo   TIP: 0_MENU.bat runs the host silently in background instead.
echo   To turn the virtual display off: run 4_STOP.bat or press Ctrl+C
echo  ============================================================
echo.
"%PYEXE%" "%~dp0core\vdd_tool.py" host
echo.
echo  Host stopped. Virtual display is off.
pause
exit /b 0

:nopython
echo.
echo  [ERROR] No Python runtime found.
echo  Keep the "runtime" folder together with these .bat files.
echo.
pause
exit /b 1

:nodriver
echo.
echo  [!] Parsec VDD driver is NOT installed / not reachable on this PC.
echo  [!] Step 1: right-click 5_INSTALL_DRIVER.bat and pick
echo           "Run as administrator"
echo  [!] Step 2: REBOOT the computer
echo  [!] Step 3: run 1_START.bat again
echo.
pause
exit /b 1
