@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PYEXE=%~dp0runtime\python.exe"
if exist "%PYEXE%" goto run
set "PYEXE=python"
:run
if not exist "%~dp0logs" mkdir "%~dp0logs"
echo stop> "%~dp0logs\STOP.flag"
echo.
echo  Stopping host and unplugging the virtual display...
ping -n 3 127.0.0.1 >nul
"%PYEXE%" "%~dp0core\vdd_tool.py" remove
echo.
echo  Done. Run 0_MENU.bat [1] (or 1_START.bat) to turn it back on.
