@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PYEXE=%~dp0runtime\python.exe"
if exist "%PYEXE%" goto run
set "PYEXE=python"
:run
echo.
"%PYEXE%" "%~dp0core\vdd_tool.py" status
echo.
pause
